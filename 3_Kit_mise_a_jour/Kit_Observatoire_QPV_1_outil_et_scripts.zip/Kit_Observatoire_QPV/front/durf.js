function DURF(b){if(!b)return {l:'n.d.',c:['#EEF1F5','#8A93A3'],t:'Bailleur absent du fichier de consommation.'};var t=b[6]||'',st=b[5]||0,fa=(b[8]||0)*365,F=function(v){return Math.round(v).toLocaleString('fr-FR')};
 if(/épuisé/.test(t))return {l:'Stock épuisé',c:['#FBE7E3','#B4232C'],t:'Plus aucun droit en stock : les familles logées ont consommé tout le stock.'};
 if(/non consommé/.test(t)||!fa)return {l:'Aucune famille logée',c:['#EEF1F5','#5B6475'],t:'Aucune famille logée sur ce stock entre 2023 et 2025 : pas de rythme pour projeter une durée. Stock : '+F(st)+' droits.'};
 var y=st/fa,raw='Stock '+F(st)+' droits ÷ '+(fa<10?fa.toLocaleString('fr-FR',{maximumFractionDigits:1}):F(fa))+' familles logées par an (moyenne 2023-2025) = '+(y<100?y.toLocaleString('fr-FR',{maximumFractionDigits:1}):F(y))+' ans.';
 if(y>30||fa<5)return {l:'Plus de 30 ans',c:['#FDE8D7','#9A3412'],t:'Projection peu fiable : rythme de consommation trop faible. '+raw};
 var a=Math.floor(y),m=Math.round((y-a)*12);if(m===12){a++;m=0}
 return {l:a+' an'+(a>1?'s':'')+(m?' '+m+' mois':''),c:y>=10?['#FFF2DC','#8A5A00']:['#E0F3F1','#0B6E69'],t:raw}}
