/* ----- focus cartographique (mode affiche) ----- */
(function(){if(location.hash.indexOf('focus')<0)return;
 document.body.classList.add('focus');
 var st=document.createElement('style');st.textContent=[
 'body.focus main{display:block!important;max-width:1500px;margin:0 auto}','body.focus main>*:not(#poster){position:absolute!important;left:-99999px!important;top:0;width:900px!important;height:700px!important;visibility:hidden}',
 'body.focus .notes,body.focus .legend,body.focus label:has(#t-qpv),body.focus label:has(#t-lab),body.focus #ind{display:none!important}',
 '#poster{background:#fff;border:1px solid #E2E5EA;border-radius:12px;overflow:hidden;font-family:"Source Sans 3",system-ui,sans-serif;color:#1B2F55}',
 '#poster .ph{background:#1B2F55;color:#fff;padding:18px 26px 16px}#poster .ph .k{font-size:12px;letter-spacing:.12em;text-transform:uppercase;opacity:.75;font-weight:700}#poster .ph h1{margin:4px 0 2px;font-size:27px;line-height:1.15;font-weight:800;letter-spacing:-.01em}#poster .ph p{margin:0;font-size:14px;opacity:.85}',
 '#poster .styles{display:flex;gap:6px;flex-wrap:wrap;padding:12px 26px;border-bottom:1px solid #EEF0F3;background:#F7F8FA}#poster .styles button{border:1px solid #CDD2DA;background:#fff;border-radius:99px;padding:6px 14px;font:600 13px inherit;color:#1B2F55;cursor:pointer}#poster .styles button[aria-pressed=true]{background:#1B2F55;color:#fff;border-color:#1B2F55}',
 '#poster .pb{display:grid;grid-template-columns:330px minmax(0,1fr);min-height:640px}',
 '#poster .pl{padding:22px 24px;border-right:1px solid #EEF0F3;background:#FBFCFD}',
 '#poster .big{font-size:15.5px;line-height:1.5;margin:0 0 16px}#poster .big b{font-size:30px;font-weight:800;color:#1B2F55;display:block;line-height:1.05;letter-spacing:-.02em}#poster .big .q{color:#2F7FC1}',
 '#poster .ref{display:block;font-size:11px;line-height:1.35;color:#7A8394;margin-top:3px;font-weight:400}#poster .cmp{border-top:1px solid #E2E5EA;padding-top:14px;margin-top:6px;font-size:13.5px;line-height:1.5;color:#3B4557}#poster .cmp b{color:#1B2F55}',
 '#poster .top h4{margin:18px 0 8px;font-size:11.5px;letter-spacing:.1em;text-transform:uppercase;color:#5B6475}#poster .top .r{display:grid;grid-template-columns:1fr 58px;gap:2px 8px;font-size:13px;margin-bottom:6px}#poster .top .bar{grid-column:1/-1;height:6px;background:#EEF1F5;border-radius:3px;overflow:hidden}#poster .top .bar i{display:block;height:100%;background:#2F7FC1;border-radius:3px}',
 '#poster .pm{position:relative;padding:10px 14px}#poster svg.pmap{width:100%;height:640px;display:block}',
 '#poster .lg{position:absolute;right:22px;top:20px;background:rgba(255,255,255,.95);border:1px solid #E2E5EA;border-radius:8px;padding:10px 12px;font-size:12px;max-width:240px;box-shadow:0 4px 14px rgba(16,24,40,.06)}#poster .lg div{display:flex;gap:8px;align-items:center;margin:3px 0}#poster .lg i{width:22px;height:13px;border-radius:2px;display:inline-block;flex:none}#poster .lg .c{border-radius:50%;width:15px;height:15px}',
 '#poster .pf{display:flex;justify-content:space-between;gap:12px;padding:10px 26px;border-top:1px solid #EEF0F3;font-size:11.5px;color:#6B778A}',
 '@media print{body.focus>*:not(main){display:none!important}#poster{border:0}#poster .styles{display:none}@page{size:A4 landscape;margin:8mm}*{-webkit-print-color-adjust:exact;print-color-adjust:exact}}'
 ].join('\n');document.head.appendChild(st);
 var main=document.querySelector('main');var P=document.createElement('div');P.id='poster';main.insertBefore(P,main.firstChild);
 var STY=[['geo','Géographie prioritaire'],['pop','Population des quartiers'],['part','Part de la population en QPV'],['nb','Nombre de QPV par commune'],['parc','Parc social en QPV']],sty='geo';
 var TOT={p:0,q:0};for(var i=0;i<N;i++){TOT.p+=U.p[i]||0;TOT.q+=U.q[i]||0}if(D.nat){TOT.p=D.nat.p;TOT.q=D.nat.q}
 var NS2='http://www.w3.org/2000/svg';function E(t,a,p){var e=document.createElementNS(NS2,t);for(var k in a)e.setAttribute(k,a[k]);if(p)p.appendChild(e);return e}
 var RAMP=['#FCE3D6','#F7B79A','#EE8A66','#DD5A42','#BF3330','#8E1B26'],NB=['#FDF3C4','#F9DC6B','#F5B648','#EF8A3A','#E4573A','#B91F2E'];
 function qOf(i){var a=qByCom[U.c[i]];if(a&&a.length)return a;var p=U.pa[U.c[i]];if(!p||!qByCom[p])return [];var b=G[i].b;return qByCom[p].filter(function(k){var q=QG[k].b,cx=(q[0]+q[2])/2,cy=(q[1]+q[3])/2;return cx>=b[0]&&cx<=b[2]&&cy>=b[1]&&cy<=b[3]})}
 function nq(i){return (qOf(i)||[]).length}
 function draw(){var M=members.slice();if(!M.length)return;var t=cur;
  var pop=0,pq=0,ls=0,lq=0,nc=0,qs={};M.forEach(function(i){pop+=U.p[i]||0;pq+=U.q[i]||0;ls+=S.tot[i]||0;lq+=S.qpv[i]||0;var a=qOf(i)||[];if(a.length)nc++;a.forEach(function(k){qs[k]=1})});if(level!=='e'){var dp2={};M.forEach(function(i){dp2[U.d[i]]=1});Q.d.forEach(function(d,k){if(dp2[d])qs[k]=1})}
  var nQ=Object.keys(qs).length,sh=pop?100*pq/pop:0,shF=100*TOT.q/TOT.p;
  var top=M.filter(function(i){return U.q[i]>0}).sort(function(a,b){return U.q[b]-U.q[a]}).slice(0,7),mx=top.length?Math.max.apply(null,top.map(function(i){return 100*U.q[i]/U.p[i]})):1;
  var lvl=(level==='e'?'l\'intercommunalité':level==='d'?'le département':'la direction régionale');
  P.innerHTML='<div class="ph"><div class="k">Focus cartographique · quartiers prioritaires 2024</div><h1>La géographie prioritaire · '+t.label+'</h1><p>'+fmt.format(M.length)+' communes · '+fmt.format(nc)+' avec au moins un quartier prioritaire</p></div>'+
  '<div class="styles">'+STY.map(function(s){return '<button data-s="'+s[0]+'" aria-pressed="'+(s[0]===sty)+'">'+s[1]+'</button>'}).join('')+'</div>'+
  '<div class="pb"><div class="pl">'+
   '<p class="big"><b>'+fmt.format(pq)+'</b>habitants vivent dans '+(nQ>1?'un des <b class="q" style="display:inline;font-size:inherit">'+nQ+' quartiers prioritaires</b>':'le quartier prioritaire')+' de '+lvl+'<span class="ref">Population municipale 2020 des QPV 2024, Insee</span></p>'+
   '<p class="big"><b class="q">'+pct(sh)+'</b>de la population de '+lvl+' vit en QPV, contre '+pct(shF)+' en France<span class="ref">Habitants en QPV / population municipale totale ('+fmt.format(pq)+' / '+fmt.format(pop)+'), Insee 2020. France : toutes communes, outre-mer compris.</span></p>'+
   (ls?'<p class="big"><b>'+pct(100*lq/ls)+'</b>des logements sociaux de '+lvl+' sont situés dans un QPV<span class="ref">Logements sociaux localisés en QPV / parc social total ('+fmt.format(lq)+' / '+fmt.format(ls)+'), RPLS 2024</span></p>':'')+
   '<div class="top"><h4>Communes les plus concernées</h4><div class="ref" style="margin:-4px 0 8px">Part des habitants de la commune vivant en QPV (Insee 2020). Classement par nombre d\'habitants en QPV.</div>'+top.map(function(i){var v=100*U.q[i]/U.p[i];return '<div class="r"><span>'+U.n[i]+' <span style="color:#6B778A">· '+fmt.format(U.q[i])+' hab.</span></span><b style="text-align:right">'+pct(v)+'</b><div class="bar"><i style="width:'+Math.max(3,100*v/mx)+'%"></i></div></div>'}).join('')+'</div>'+
   '<div class="cmp"><b>'+(TOT.q/1e6).toLocaleString('fr-FR',{maximumFractionDigits:1})+' millions</b> d\'habitants vivent en QPV en France, soit <b>'+pct(shF)+'</b> de la population.<span class="ref">Population municipale 2020, toutes communes de l\'outil, outre-mer compris (Insee, populations de référence QPV 2024). Liste officielle 2024 : 1 584 QPV dont 222 en outre-mer.</span></div>'+
  '</div><div class="pm"><svg class="pmap" role="img" aria-label="Carte de la géographie prioritaire"></svg><div class="lg"></div></div></div>'+
  '<div class="pf"><span>Sources : ANCT, quartiers prioritaires 2024 ; Insee, populations 2020 ; RPLS 2024. Fonds : Etalab, IGN.</span><span>Action Logement Services · DFBC-POM · Pôle Process Outils et Méthodes · '+new Date().toLocaleDateString('fr-FR',{month:'long',year:'numeric'})+'</span></div>';
  P.querySelectorAll('.styles button').forEach(function(b){b.onclick=function(){sty=b.dataset.s;draw()}});
  mapDraw(M);}
 function mapDraw(M){var svgP=P.querySelector('svg.pmap'),lg=P.querySelector('.lg');var z=UZ[M[0]],x0=1e12,y0=1e12,x1=-1e12,y1=-1e12;
  M.forEach(function(i){var b=G[i].b;if(b[0]<x0)x0=b[0];if(b[1]<y0)y0=b[1];if(b[2]>x1)x1=b[2];if(b[3]>y1)y1=b[3]});
  var W=svgP.getBoundingClientRect().width||900,H=640,pw=(x1-x0)*.06,ph=(y1-y0)*.06,vb=[x0-pw,y0-ph,x1-x0+2*pw,y1-y0+2*ph];
  var r=W/H;if(vb[2]/vb[3]<r){var w=vb[3]*r;vb[0]-=(w-vb[2])/2;vb[2]=w}else{var h=vb[2]/r;vb[1]-=(h-vb[3])/2;vb[3]=h}
  svgP.setAttribute('viewBox',vb.join(' '));svgP.innerHTML='';var sc=vb[2]/W,ms=new Set(M);
  var gN=E('g',{},svgP),gO=E('g',{},svgP),gC=E('g',{},svgP),gQ=E('g',{},svgP),gD=E('g',{},svgP),gL=E('g',{},svgP),gU=E('g',{},svgP);
  for(var i=0;i<N;i++){if(ms.has(i)||UZ[i]!==z)continue;var b=G[i].b;if(b[2]<vb[0]||b[0]>vb[0]+vb[2]||b[3]<vb[1]||b[1]>vb[1]+vb[3])continue;E('path',{d:G[i].d,fill:sty==='pop'?'#D9D9D9':'#F3F4F6',stroke:sty==='pop'?'#8A8A8A':'#fff','stroke-width':1.2*sc},gN)}
  if(sty==='pop'){var df=E('defs',{},svgP);var fl=E('filter',{id:'halo',x:'-10%',y:'-10%',width:'120%',height:'120%'},df);E('feGaussianBlur',{stdDeviation:14*sc},fl);var gH=E('g',{filter:'url(#halo)'},gO);M.forEach(function(i){E('path',{d:G[i].d,fill:'#000',stroke:'#000','stroke-width':16*sc,'fill-opacity':.55,'stroke-opacity':.55},gH)});
 var rg=E('radialGradient',{id:'sph',cx:'32%',cy:'30%',r:'75%'},df);E('stop',{offset:'0','stop-color':'#F4ECF7'},rg);E('stop',{offset:'.45','stop-color':'#9A5BAF'},rg);E('stop',{offset:'1','stop-color':'#4A1260'},rg)}
 M.forEach(function(i){E('path',{d:G[i].d,fill:'none',stroke:'#1A1A1A','stroke-width':5*sc,'stroke-linejoin':'round'},gO)});
  function fillOf(i){var n=nq(i);if(sty==='pop')return '#fff';if(sty==='geo')return n?'#DCE3EC':'#fff';if(sty==='nb')return n?NB[Math.min(5,n<=4?n-1:n<=6?4:5)]:'#fff';
   var v=sty==='part'?(U.p[i]?100*U.q[i]/U.p[i]:0):(S.tot[i]?100*S.qpv[i]/S.tot[i]:0);var br=sty==='part'?[5,10,20,30,40]:[10,25,40,55,70];if(!v)return '#fff';for(var k=0;k<5;k++)if(v<br[k])return RAMP[k];return RAMP[5]}
  M.forEach(function(i){var p=E('path',{d:G[i].d,fill:fillOf(i),stroke:'#9AA3B0','stroke-width':.8*sc},gC);var tt=E('title',{},p);tt.textContent=U.n[i]+(U.q[i]?' · '+fmt.format(U.q[i])+' habitants en QPV ('+pct(100*U.q[i]/U.p[i])+')':'')});
  var qk=[];Q.q.forEach(function(c,k){if(QZ[k]!==z)return;var b=QG[k].b;if(b[2]<vb[0]||b[0]>vb[0]+vb[2]||b[3]<vb[1]||b[1]>vb[1]+vb[3])return;qk.push(k);
   var p=E('path',{d:QG[k].d,fill:sty==='geo'?'#2F8FCE':sty==='pop'?'#D88FB8':'none',stroke:sty==='geo'?'#1C5F92':sty==='pop'?'#E0284B':'#1B2F55','stroke-width':(sty==='geo'?.9:1.3)*sc,'fill-opacity':sty==='geo'?.95:1},gQ);var tt=E('title',{},p);tt.textContent=Q.n[k]+' · '+fmt.format(Q.p[k])+' habitants'});
  if(sty==='geo')qk.filter(function(k){return Q.p[k]>=5000}).forEach(function(k){var b=QG[k].b;E('circle',{cx:(b[0]+b[2])/2,cy:(b[1]+b[3])/2,r:6.5*sc,fill:'#FFD43B',stroke:'#1B2F55','stroke-width':1.2*sc},gD)});
  var mq={};M.forEach(function(i){(qOf(i)||[]).forEach(function(k){mq[k]=1})});if(level!=='e'){var dp={};M.forEach(function(i){dp[U.d[i]]=1});Q.d.forEach(function(d,k){if(dp[d])mq[k]=1})}if(sty==='pop'){qk=qk.filter(function(k){return mq[k]})}
  if(sty==='pop'){var qmax=Math.max.apply(null,qk.map(function(k){return Q.p[k]}).concat([1]));var K=Math.min(vb[2],vb[3])*.075/Math.sqrt(qmax);window.__popK=[K/sc,qmax];
   var gS=E('g',{},svgP);svgP.insertBefore(gS,gQ);qk.slice().sort(function(a,b){return Q.p[b]-Q.p[a]}).forEach(function(k){var b=QG[k].b;var c=E('circle',{cx:(b[0]+b[2])/2,cy:(b[1]+b[3])/2,r:K*Math.sqrt(Q.p[k]),fill:'url(#sph)','fill-opacity':.92,stroke:'#4A1260','stroke-width':.6*sc},gS);var tt=E('title',{},c);tt.textContent=Q.n[k]+' · '+fmt.format(Q.p[k])+' habitants'});}
  /* étiquettes : communes en capitales, quartiers en bleu italique */
  var boxes=[];function put(x,y,txt,fs,cls,fill,stroke){var w=txt.length*fs*.56,h=fs*1.15,bx=[x-w/2,y-h/2,x+w/2,y+h/2];if(bx[0]<vb[0]||bx[2]>vb[0]+vb[2]||bx[1]<vb[1]||bx[3]>vb[1]+vb[3])return false;
   if(boxes.some(function(o){return !(bx[2]<o[0]||bx[0]>o[2]||bx[3]<o[1]||bx[1]>o[3])}))return false;boxes.push(bx);
   var t=E('text',{x:x,y:y,'text-anchor':'middle','dominant-baseline':'middle',style:'font:'+cls+' '+fs+'px "Source Sans 3",sans-serif;fill:'+fill+';paint-order:stroke;stroke:#fff;stroke-width:'+stroke*sc+'px;stroke-linejoin:round'},gL);t.textContent=txt;return true}
  if(sty==='pop'){var K2=window.__popK[0]*sc;qk.forEach(function(k){var b=QG[k].b,cx=(b[0]+b[2])/2,cy=(b[1]+b[3])/2;boxes.push([cx-K2*Math.sqrt(Q.p[k]),cy-K2*Math.sqrt(Q.p[k]),cx+K2*Math.sqrt(Q.p[k]),cy+K2*Math.sqrt(Q.p[k])])});
   var gB=E('g',{},svgP);qk.slice().sort(function(a,b){return Q.p[b]-Q.p[a]}).slice(0,26).forEach(function(k){var b=QG[k].b,cx=(b[0]+b[2])/2,cy=(b[1]+b[3])/2,rr=K2*Math.sqrt(Q.p[k]),txt=Q.n[k],fs=12.5*sc,w=txt.length*fs*.56+12*sc,h=fs*1.75;
    for(var d=1;d<=7;d++){var ok=false;for(var a=0;a<16;a++){var an=a*Math.PI/8+(d%2?0:Math.PI/16),R=rr+d*26*sc,x=cx+Math.cos(an)*R,y=cy+Math.sin(an)*R*.8,bx=[x-w/2,y-h/2,x+w/2,y+h/2];
     if(bx[0]<vb[0]||bx[2]>vb[0]+vb[2]||bx[1]<vb[1]||bx[3]>vb[1]+vb[3])continue;if(boxes.some(function(o){return !(bx[2]<o[0]||bx[0]>o[2]||bx[3]<o[1]||bx[1]>o[3])}))continue;boxes.push(bx);
     E('line',{x1:cx,y1:cy,x2:x,y2:y,stroke:'#1A1A1A','stroke-width':1.1*sc},gB);E('rect',{x:bx[0],y:bx[1],width:w,height:h,fill:'#fff',stroke:'#1A1A1A','stroke-width':1.6*sc},gB);var t=E('text',{x:x,y:y,'text-anchor':'middle','dominant-baseline':'middle',style:'font:700 '+fs+'px "Source Sans 3",sans-serif;fill:#1A1A1A'},gB);t.textContent=txt;ok=true;break}if(ok)break}});}
  var maxL=Math.round(W/34),nL=0;
  M.slice().sort(function(a,b){return (U.q[b]||0)-(U.q[a]||0)||U.p[b]-U.p[a]}).forEach(function(i){if(nL>=maxL)return;var x=U.l[2*i]*UN/CU,y=-U.l[2*i+1]*UN/CU;if(put(x,y,U.n[i].toUpperCase(),(U.q[i]?12:10.5)*sc,U.q[i]?'800':'600',U.q[i]?'#1A1A1A':'#6B778A',3.2))nL++});
  if(sty!=='pop')qk.filter(function(k){return mq[k]}).sort(function(a,b){return Q.p[b]-Q.p[a]}).slice(0,Math.round(maxL*1.2)).forEach(function(k){var b=QG[k].b;put((b[0]+b[2])/2,b[3]+10*sc,Q.n[k],11*sc,'italic 600',sty==='geo'?'#1C5F92':'#1B2F55',3)});
  /* échelle et nord */
  var mpu=CU,target=vb[2]*mpu*.18,steps=[500,1000,2000,2500,5000,10000,20000,25000,50000,100000],len=steps[0];steps.forEach(function(s){if(s<=target)len=s});
  var bx=vb[0]+vb[2]*.04,by=vb[1]+vb[3]*.95,L=len/mpu;
  [[0,'#1A1A1A'],[L/2,'#fff'],[L/4,'#fff']].slice(0,1);
  E('rect',{x:bx,y:by-4*sc,width:L/2,height:6*sc,fill:'#1A1A1A'},gU);E('rect',{x:bx+L/2,y:by-4*sc,width:L/2,height:6*sc,fill:'#fff',stroke:'#1A1A1A','stroke-width':sc},gU);
  [[bx,'0'],[bx+L/2,(len/2>=1000?len/2000:len/2)+''],[bx+L,(len>=1000?len/1000+' km':len+' m')]].forEach(function(a){var t=E('text',{x:a[0],y:by-9*sc,'text-anchor':'middle',style:'font:600 '+11*sc+'px "Source Sans 3",sans-serif;fill:#1A1A1A'},gU);t.textContent=a[1]});
  var nx=vb[0]+vb[2]*.04+L+40*sc,ny=by-6*sc;E('path',{d:'M'+nx+' '+(ny-34*sc)+'l'+(-8*sc)+' '+(26*sc)+'l'+(8*sc)+' '+(-7*sc)+'z',fill:'#1A1A1A'},gU);E('path',{d:'M'+nx+' '+(ny-34*sc)+'l'+(8*sc)+' '+(26*sc)+'l'+(-8*sc)+' '+(-7*sc)+'z',fill:'#fff',stroke:'#1A1A1A','stroke-width':sc},gU);var tn=E('text',{x:nx,y:ny+8*sc,'text-anchor':'middle',style:'font:700 '+12*sc+'px "Source Sans 3",sans-serif'},gU);tn.textContent='N';
  /* légende */
  var h='';if(sty==='pop'){var KK=window.__popK[0],qm=window.__popK[1],tp=qk.reduce(function(a,k){return a+Q.p[k]},0),vals=[qm,Math.round(qm/3/100)*100||Math.round(qm/3),Math.round(qm/9/100)*100||Math.round(qm/9)];
   h='<b style="display:block;margin-bottom:6px">Population des quartiers</b>'+vals.map(function(v){var d=2*KK*Math.sqrt(v);return '<div><span style="display:inline-block;width:'+Math.max(10,d)+'px;height:'+Math.max(10,d)+'px;border-radius:50%;background:radial-gradient(circle at 32% 30%,#F4ECF7,#9A5BAF 45%,#4A1260)"></span><span>'+fmt.format(v)+' habitants</span></div>'}).join('')+'<div style="margin-top:6px"><i style="background:#D88FB8;border:1px solid #E0284B"></i>Quartier prioritaire</div><div><i style="background:#fff;border:2.5px solid #1A1A1A"></i>Territoire</div><div style="margin-top:6px;font-weight:700">Population totale des quartiers : '+fmt.format(tp)+' habitants</div>'}
  else if(sty==='geo')h='<b style="display:block;margin-bottom:5px">Géographie prioritaire 2024</b><div><i style="background:#2F8FCE;border:1px solid #1C5F92"></i>Quartier prioritaire (QPV)</div><div><i style="background:#DCE3EC;border:1px solid #9AA3B0"></i>Commune avec au moins un QPV</div><div><i class="c" style="background:#FFD43B;border:1.5px solid #1B2F55"></i>QPV de plus de 5 000 habitants</div><div><i style="background:#fff;border:2.5px solid #1A1A1A"></i>Limite du territoire</div>';
  else if(sty==='nb')h='<b style="display:block;margin-bottom:5px">Nombre de QPV par commune</b><div style="gap:5px">'+['1','2','3','4','5-6','7+'].map(function(l,k){return '<span style="display:inline-grid;place-items:center;width:26px;height:26px;border-radius:50%;background:'+NB[k]+';font-weight:700;font-size:11px;color:'+(k>3?'#fff':'#1B2F55')+'">'+l+'</span>'}).join('')+'</div><div><i style="background:none;border:1.3px solid #1B2F55"></i>Contour des QPV</div>';
  else{var br=sty==='part'?[5,10,20,30,40]:[10,25,40,55,70];var lab=['Moins de '+br[0]+' %'].concat(br.slice(0,4).map(function(b,k){return b+' à '+br[k+1]+' %'})).concat([br[4]+' % ou plus']);
   h='<b style="display:block;margin-bottom:5px">'+(sty==='part'?'Part des habitants vivant en QPV':'Part du parc social situé en QPV')+'</b>'+lab.map(function(l,k){return '<div><i style="background:'+RAMP[k]+'"></i>'+l+'</div>'}).reverse().join('')+'<div><i style="background:#fff;border:1px solid #9AA3B0"></i>Aucun</div><div><i style="background:none;border:1.3px solid #1B2F55"></i>Contour des QPV</div>'}
  lg.innerHTML=h}
 window.__focusDraw=draw;
 var _r=render;render=function(t){_r(t);try{draw()}catch(e){console.log(e.stack)}};try{draw()}catch(e){console.log(e.stack)}
 window.__printHTML=function(){var css=[].map.call(document.querySelectorAll('style'),function(s){return s.textContent}).join('\n');return '<!doctype html><html lang="fr"><head><meta charset="utf-8"><title>Focus · '+cur.label+'</title><link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Source+Sans+3:wght@400;600;700;800&display=swap"><style>'+css+'\nbody{margin:0;background:#fff}#poster .styles{display:none}#poster svg.pmap{height:150mm}#poster .pb{min-height:0}@page{size:A4 landscape;margin:7mm}*{-webkit-print-color-adjust:exact;print-color-adjust:exact}</style></head><body class="focus">'+P.outerHTML+'</body></html>'};
})();
