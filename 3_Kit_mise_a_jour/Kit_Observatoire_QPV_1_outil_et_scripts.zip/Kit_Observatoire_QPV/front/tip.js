/* ----- infobulles ----- */
(function(){var b=document.createElement('div');b.id='tipb';b.style.cssText='position:fixed;z-index:99999;max-width:300px;background:#1B2F55;color:#fff;font:13px/1.45 "Source Sans 3",system-ui,sans-serif;padding:8px 11px;border-radius:7px;box-shadow:0 8px 24px rgba(16,24,40,.25);pointer-events:none;opacity:0;transition:opacity .12s;left:0;top:0';
 function add(){document.body.appendChild(b)}if(document.body)add();else document.addEventListener('DOMContentLoaded',add);
 var st=document.createElement('style');st.textContent='[data-tip]{cursor:help}[data-tip].tipi::after{content:"i";display:inline-grid;place-items:center;width:14px;height:14px;margin-left:5px;border-radius:50%;border:1px solid currentColor;font:700 9.5px/1 Georgia,serif;font-style:italic;opacity:.55;vertical-align:1px}';document.head.appendChild(st);
 var cur=null;
 function show(el,e){var t=el.getAttribute('data-tip');if(!t)return;b.textContent=t;b.style.opacity=1;move(e)}
 function move(e){var w=b.offsetWidth,h=b.offsetHeight,x=e.clientX+14,y=e.clientY+16;if(x+w>innerWidth-8)x=e.clientX-w-12;if(y+h>innerHeight-8)y=e.clientY-h-12;b.style.left=Math.max(6,x)+'px';b.style.top=Math.max(6,y)+'px'}
 document.addEventListener('mouseover',function(e){var el=e.target.closest&&e.target.closest('[data-tip],[title]');if(el&&el.hasAttribute('title')&&!el.closest('.leaflet-container svg')){var t=el.getAttribute('title');if(t){el.setAttribute('data-tip',t)}el.removeAttribute('title')}
  el=e.target.closest&&e.target.closest('[data-tip]');if(el!==cur){cur=el;if(el)show(el,e);else b.style.opacity=0}});
 document.addEventListener('mousemove',function(e){if(cur)move(e)});
 document.addEventListener('scroll',function(){b.style.opacity=0;cur=null},true);
 window.__tipMap=function(map){function ap(){map.forEach(function(m){document.querySelectorAll(m[0]).forEach(function(el){if(!el.hasAttribute('data-tip')){el.setAttribute('data-tip',m[1]);if(m[2])el.classList.add('tipi')}})})}
  ap();new MutationObserver(function(){clearTimeout(window.__tipT);window.__tipT=setTimeout(ap,120)}).observe(document.body,{childList:true,subtree:true})};
})();
