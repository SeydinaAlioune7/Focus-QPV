/* ----- mesurer entre deux points ----- */
const MS={A:null,B:null,pick:null};let MSL=null;
const pinI=(t,c)=>L.divIcon({className:'',html:`<div style="width:24px;height:24px;border-radius:50%;background:${c};color:#fff;font:700 12px/24px var(--body);text-align:center;border:2px solid #fff;box-shadow:0 2px 8px rgba(0,0,0,.35);transform:translate(-12px,-12px)">${t}</div>`});
async function nameAt(lat,lon){
 let best=null,bd=.06;const cand=(n,la,lo)=>{const d=hav(lat,lon,la,lo);if(d<bd){bd=d;best=n}};
 OBS.GARES.forEach(g=>cand('Gare '+g[0],g[1],g[2]));
 if(window.PQDATA)window.PQDATA.S.forEach(s=>cand(({E:'École',C:'Collège',L:'Lycée'}[s[2]]||'')+' '+s[5],s[0],s[1]));
 try{const {P,PD}=window.RPLSGET();around(lat,lon,.06).forEach(([i,d])=>{if(d<bd){bd=d;best=fr(P.tot[i])+' logement'+(P.tot[i]>1?'s':'')+' '+PD.b[P.b[i]]}})}catch(e){}
 if(best)return best;const q=qpvAt(lat,lon);
 try{const r=await fetch('https://data.geopf.fr/geocodage/reverse?lon='+lon+'&lat='+lat+'&limit=1');const f=(await r.json()).features[0];if(f)return f.properties.label+(q?' (QPV '+q.lib_qp+')':'')}catch(e){}
 return q?'QPV '+q.lib_qp:'Point '+lat.toFixed(5)+', '+lon.toFixed(5)}
function msSet(k,lat,lon,n){MS[k]={lat,lon,n};document.getElementById('ms'+k).value=n;msRun()}
window.__msPick=async(lat,lon)=>{const k=MS.pick;if(!k)return false;MS.pick=null;msUI();document.getElementById('ms'+k).value='Recherche du lieu…';msSet(k,lat,lon,await nameAt(lat,lon));return true};
function msUI(){['A','B'].forEach(k=>document.getElementById('mp'+k).classList.toggle('on',MS.pick===k));document.getElementById('amap').style.cursor=MS.pick?'crosshair':''}
async function route(a,b,p){const u='https://data.geopf.fr/navigation/itineraire?resource=bdtopo-osrm&start='+a.lon+','+a.lat+'&end='+b.lon+','+b.lat+'&profile='+p+'&optimization=fastest&geometryFormat=geojson&getSteps=false&timeUnit=minute&distanceUnit=kilometer';const r=await fetch(u);if(!r.ok)throw 0;const j=await r.json();return{km:+j.distance,min:+j.duration,geo:j.geometry}}
const hm=m=>m<60?Math.max(1,Math.round(m))+' min':Math.floor(m/60)+' h '+String(Math.round(m%60)).padStart(2,'0');
async function msRun(){const out=document.getElementById('msout');if(!MSL)MSL=L.layerGroup().addTo(am);MSL.clearLayers();
 ['A','B'].forEach(k=>{if(MS[k])L.marker([MS[k].lat,MS[k].lon],{icon:pinI(k,k==='A'?'#1B2F55':'#E2004B'),zIndexOffset:2000}).bindTooltip(MS[k].n,{className:'tp'}).addTo(MSL)});
 if(!MS.A||!MS.B){out.innerHTML='';return}
 const vo=hav(MS.A.lat,MS.A.lon,MS.B.lat,MS.B.lon);out.innerHTML='<div class="note">Calcul des itinéraires…</div>';
 am.fitBounds(L.latLngBounds([[MS.A.lat,MS.A.lon],[MS.B.lat,MS.B.lon]]).pad(.25));
 const [c,p]=await Promise.all([route(MS.A,MS.B,'car').catch(()=>null),route(MS.A,MS.B,'pedestrian').catch(()=>null)]);
 if(p&&p.geo)L.geoJSON(p.geo,{style:{color:'#1E9E95',weight:4,opacity:.8,dashArray:'2 7',lineCap:'round'}}).addTo(MSL);
 if(c&&c.geo)L.geoJSON(c.geo,{style:{color:'#1B2F55',weight:5,opacity:.75}}).addTo(MSL);
 const row=(ic,lab,r,est)=>`<div class="msr"><span>${ic}</span><div><b>${lab}</b><small>${r?dist(r.km)+' par la route':dist(est.km)+' (estimation)'}</small></div><strong>${r?hm(r.min):hm(est.min)}${r?'':'*'}</strong></div>`;
 out.innerHTML=`<div class="msbox"><div class="msr"><span><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#6B778A" stroke-width="2" stroke-dasharray="3 3"><path d="M4 20L20 4"/></svg></span><div><b>À vol d'oiseau</b><small>distance directe</small></div><strong>${dist(vo)}</strong></div>`+row('<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#1B2F55" stroke-width="2"><path d="M5 16V11l2-5h10l2 5v5M3 16h18M7 19v-3M17 19v-3M5 11h14"/></svg>','En voiture',c,{km:vo*1.3,min:vo*1.3/40*60})+row('<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#1E9E95" stroke-width="2"><circle cx="13" cy="4" r="2"/><path d="M10 21l2-6 3 3v3M9 12l2-4 4 2 2 3M11 8l-3 5"/></svg>','À pied',p,{km:vo*1.25,min:vo*1.25/4.5*60})+`</div><div class="note">Itinéraires IGN (BD TOPO), sans trafic.${c&&p?'':' * Service injoignable : estimation.'}</div>`;
 A.mes=[MS.A.n,MS.B.n,vo,c&&c.km,c&&c.min,p&&p.km,p&&p.min]}
function msSearch(k){const inp=document.getElementById('ms'+k),box=document.getElementById('mg'+k);let t=null;
 inp.addEventListener('input',()=>{clearTimeout(t);const v=inp.value.trim();if(v.length<3){box.hidden=true;return}t=setTimeout(async()=>{const c=am?am.getCenter():{lat:46.6,lng:2.4};
  const q=encodeURIComponent(v),ll='&lat='+c.lat+'&lon='+c.lng;
  const [a,b,o]=await Promise.all([fetch('https://data.geopf.fr/geocodage/search?q='+q+'&limit=4'+ll).then(r=>r.json()).catch(()=>({})),fetch('https://data.geopf.fr/geocodage/search?q='+q+'&index=poi&limit=4'+ll).then(r=>r.json()).catch(()=>({})),fetch('https://photon.komoot.io/api/?q='+q+'&limit=4&lang=fr'+ll).then(r=>r.json()).catch(()=>({}))]);
  const it=[];(a.features||[]).forEach(f=>it.push([f.properties.label,f.geometry.coordinates,'Adresse']));
  (b.features||[]).forEach(f=>{const p=f.properties;it.push([(p.toponym||(p.name&&p.name[0])||p.label||v)+(p.city?', '+(Array.isArray(p.city)?p.city[0]:p.city):''),f.geometry.coordinates,(Array.isArray(p.category)?p.category[0]:p.category)||'Lieu'])});
  (o.features||[]).forEach(f=>{const p=f.properties;if(p.name)it.push([p.name+(p.city?', '+p.city:''),f.geometry.coordinates,(p.osm_value||'lieu').replace(/_/g,' ')])});
  // éléments de l'outil : gares, établissements scolaires, QPV
  const lv=v.toLowerCase();OBS.GARES.filter(g=>('gare '+g[0]).toLowerCase().includes(lv)).slice(0,3).forEach(g=>it.unshift(['Gare '+g[0],[g[2],g[1]],'Gare']));
  if(window.PQDATA)window.PQDATA.S.filter(s=>s[5].toLowerCase().includes(lv)).slice(0,3).forEach(s=>it.push([s[5],[s[1],s[0]],{E:'École',C:'Collège',L:'Lycée'}[s[2]]]));
  QG.features.filter(f=>f.properties.lib_qp.toLowerCase().includes(lv)).slice(0,3).forEach(f=>{const b=L.geoJSON(f).getBounds().getCenter();it.push(['QPV '+f.properties.lib_qp,[b.lng,b.lat],'Quartier prioritaire'])});
  if(!it.length){box.hidden=true;return}box.innerHTML=it.slice(0,10).map(x=>`<div data-la="${x[1][1]}" data-lo="${x[1][0]}" data-n="${x[0].replace(/"/g,'&quot;')}">${x[0]}<span style="float:right;color:var(--mut);font-size:11.5px">${x[2]}</span></div>`).join('');box.hidden=false},300)});
 box.addEventListener('click',e=>{const d=e.target.closest('div[data-la]');if(!d)return;box.hidden=true;msSet(k,+d.dataset.la,+d.dataset.lo,d.dataset.n)});
 inp.addEventListener('keydown',e=>{if(e.key==='Enter'){const d=box.querySelector('div[data-la]');if(d)d.click()}});
 document.getElementById('mp'+k).onclick=()=>{initAdr();MS.pick=MS.pick===k?null:k;msUI()}}
msSearch('A');msSearch('B');
document.getElementById('msu').onclick=()=>{if(A.pt)msSet('A',A.pt.lat,A.pt.lon,A.pt.label)};
document.getElementById('msx').onclick=()=>{const t=MS.A;MS.A=MS.B;MS.B=t;document.getElementById('msA').value=MS.A?MS.A.n:'';document.getElementById('msB').value=MS.B?MS.B.n:'';msRun()};
document.getElementById('msc').onclick=()=>{MS.A=MS.B=null;MS.pick=null;msUI();['A','B'].forEach(k=>document.getElementById('ms'+k).value='');msRun()};
