sh=open('app_shell.html').read();logo=open('logo_src.txt').read()
pj=open('portrait.js').read()
pj=pj.replace("const PQ=JSON.parse(document.getElementById('qpvPortrait').textContent);","const PQ=JSON.parse(document.getElementById('qpvPortrait').textContent);window.PQDATA=PQ;",1)
pj=pj.replace("${q.n} — ${q.com} (${c})","${q.n} · ${q.com} (${c})").replace("q.n+' — '+q.com+' ('+code+')'","q.n+' · '+q.com+' ('+code+')'").replace("setTab('v')","go('qpv')")
core=open('app_core.js').read();adr=open('app_adr.js').read()
app=open('tip.js').read()+core+"\n(function(){"+pj+"\n})();\n"+adr+"\n"+open('app_acc.js').read()+"\n"+open('app_ze.js').read()+"\n"+open('app_mes.js').read()+"\n"+open('tips_app.js').read()+"\nconst start=(location.hash.slice(1).split('&')[0])||'atlas';go(['atlas','focus','qpv','adresse','methodes'].includes(start)?start:'atlas');"
ATL=open('atlas_override.css').read()
atlas=open('atlas_qpv.html').read().replace('</style>',ATL+'</style>',1).replace(' — ',' · ')
_e=atlas.rfind('})()',0,atlas.rfind('</script>'));atlas=atlas[:_e]+open('atlas_export.js').read()+open('atlas_resa.js').read()+open('atlas_evol.js').read()+open('atlas_focus.js').read()+open('tip.js').read()+open('tips_atlas.js').read()+'\n'+atlas[_e:]
atlas=atlas.replace("const S=D.S;","const S=D.S;const RS=JSON.parse(document.getElementById('resa').textContent);(function(){var m={};RS.R.forEach(function(r){m[r[0]]=(m[r[0]]||0)+r[2]});S.res=U.c.map(function(c){return m[c]||0})})();",1)
atlas=atlas.replace(" vac:{t:"," res:{t:'Logements réservés ALS pour 100 logts sociaux',k:'logements réservés par ALS (2018-2025) pour 100 logements sociaux',v:i=>S.tot[i]>0?100*S.res[i]/S.tot[i]:null,num:i=>S.res[i],den:i=>S.tot[i],br:[2,5,10,20,35],z:'Aucune réservation',nd:'Pas de logement social'},\n vac:{t:",1)
atlas=atlas.replace("['att','Familles logées pour 100","['res','Logements réservés pour 100 logements sociaux','Logements réservés par Action Logement lors des engagements 2018-2025, rapportés au parc social de la commune.','POLARIS · engagements personnes morales 2018-2025'],['att','Familles logées pour 100",1)
atlas=atlas.replace('<option value="att">','<option value="res">Logements réservés ALS</option><option value="att">',1)
atlas=atlas.replace("ind==='att'","(ind==='att'||ind==='res')").replace('return [IND.att.z,','return [IND[ind].z,')
atlas=atlas.replace('<script id="data" type="application/json">','<script id="resa" type="application/json">'+open('resa.json').read()+'</script><script id="evol" type="application/json">'+open('evol.json').read()+'</script><script id="data" type="application/json">',1)
atlas='<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Source+Sans+3:wght@400;600;700&display=swap">'+atlas
doc=('<!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>html,body{margin:0}</style></head><body>'+atlas+'<script>(function(){function f(){var l=document.getElementById("legend");if(!l)return setTimeout(f,300);l.addEventListener("click",function(e){if(e.target.closest("h3"))l.classList.toggle("min")});if(innerWidth<900)l.classList.add("min")}f()})();</script></body></html>').replace('</script','<\\/script')
blocks=''.join('<script type="application/json" id="%s">%s</script>\n'%(i,open(f).read().replace('</','<\\/')) for i,f in [('zeData','ze_geo.json'),('resaData','resa.json'),('opsData','ops.json'),('obsSmall','obs_small.json'),('rplsPts','rpls_pts.json'),('qpvGeo','qpv_wgs_simpl.json'),('qpvPortrait','qpv_portrait.json')])
blocks+='<script type="text/plain" id="atlasSrc">'+doc+'</script>\n'
out=sh.replace('/*LEAFLET*/',open('leaflet.css').read()).replace('__LOGO__',logo).replace('__DATA__',blocks).replace('__LEAFLET_JS__',open('leaflet.js.html').read()).replace('__APP__',app).replace('__METHODES__',open('methodes.html').read())
out=out.replace('#atlasFrame{width:100%;height:calc(100vh - 150px);min-height:640px;','#atlasFrame{width:100%;height:calc(100vh - 90px);min-height:680px;')
open('observatoire_qpv_entreprise.html','w').write(out);print(len(out)/1e6,out.count('—'))
