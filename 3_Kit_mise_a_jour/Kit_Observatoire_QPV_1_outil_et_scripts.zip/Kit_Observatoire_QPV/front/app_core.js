/* ===== Observatoire des quartiers prioritaires · application ===== */
const J=id=>JSON.parse(document.getElementById(id).textContent);
const fr=n=>Math.round(n).toLocaleString('fr-FR'),fr1=n=>n.toLocaleString('fr-FR',{maximumFractionDigits:1});
const dist=km=>km<1?fr(Math.round(km*100)*10)+' m':fr1(km)+' km';
function hav(a,b,c,d){const R=6371,t=Math.PI/180,dl=(c-a)*t,dn=(d-b)*t,x=Math.sin(dl/2)**2+Math.cos(a*t)*Math.cos(c*t)*Math.sin(dn/2)**2;return 2*R*Math.asin(Math.min(1,Math.sqrt(x)))}
function tiles(m){const ign=L.tileLayer('https://data.geopf.fr/wmts?SERVICE=WMTS&REQUEST=GetTile&VERSION=1.0.0&LAYER=GEOGRAPHICALGRIDSYSTEMS.PLANIGNV2&STYLE=normal&TILEMATRIXSET=PM&FORMAT=image/png&TILEMATRIX={z}&TILEROW={y}&TILECOL={x}',{maxZoom:19,maxNativeZoom:18,crossOrigin:true});let err=0,ok=0,fb=false;
 const alt=()=>L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png',{subdomains:'abcd',maxZoom:20});
 ign.on('tileload',()=>{ok++});
 ign.on('tileerror',e=>{err++;const t=e.tile;if(t&&!t.dataset.retry){t.dataset.retry=1;setTimeout(()=>{t.src=t.src.split('&_r=')[0]+'&_r='+Date.now()},700);return}
  if(!fb&&err>6&&err>ok){fb=true;m.removeLayer(ign);alt().addTo(m)}});
 ign.addTo(m)}
window.__tiles=tiles;

/* ----- en-têtes de rubrique ----- */
const HERO={
 atlas:{k:'Atlas des communes',t:'Où vivent les habitants des quartiers prioritaires ?',p:'Pour chaque commune : la part des habitants en QPV, la part du parc social situé en QPV, les passoires énergétiques, la vacance et les attributions Action Logement. Choisissez un EPCI, un département ou une direction régionale.',s:['Choisissez le niveau (EPCI, département, DR) puis le territoire.','Choisissez un indicateur dans le catalogue, à gauche de la carte.','Survolez une commune ou un quartier pour le détail ; cliquez une ligne du tableau pour zoomer.']},
 qpv:{k:'Portrait d\'un quartier',t:'Que faut-il savoir sur ce quartier ?',p:'Le portrait réunit les données de l\'Insee sur les habitants, les revenus, l\'emploi, l\'éducation et le logement, les écoles et les bailleurs présents. Chaque chiffre est comparé à sa commune quand la donnée existe, et à l\'ensemble des quartiers prioritaires de France.',s:['Tapez le nom du quartier ou de la commune.','Lisez « L\'essentiel » : les écarts les plus marqués.','Parcourez les thèmes un par un.']},
 focus:{k:'Focus cartographique',t:'Une carte de synthèse prête à présenter',p:'Choisissez un territoire puis un style de carte : géographie prioritaire, population des quartiers, part de la population en QPV, nombre de QPV par commune ou parc social. La planche s\'imprime au format A4 paysage.',s:['Choisissez EPCI, département ou DR puis le territoire en haut de la planche.','Choisissez le style de carte avec les boutons.','Imprimer produit la planche seule, prête pour une note ou une présentation.']},
 methodes:{k:'Méthodes',t:'Comment l\'outil est-il construit ?',p:'Sources, millésimes, calculs, géolocalisation du parc social, temps de trajet, droits de réservation, limites et procédure de mise à jour.',s:['Utilisez le sommaire à gauche pour aller à une rubrique.','Imprimer produit la note méthodologique complète.','Exporter en CSV télécharge la liste des sources.']},
 adresse:{k:'Analyse d\'une adresse',t:'Ce logement est-il bien situé ?',p:'Pour une adresse : quartier prioritaire ou non, logement social sur place et ses étiquettes énergie, gare, emploi, entreprises et parc des bailleurs autour. Une synthèse distingue les atouts et les points de vigilance.',s:['Saisissez une adresse ou cliquez sur la carte.','Réglez le rayon et choisissez voiture ou à pied : les temps de trajet sont calculés par la route.','Lisez la synthèse puis le détail des bailleurs.']}};
function hero(p){const h=HERO[p];document.getElementById('hero').innerHTML=`<div><div class="kick">${h.k}</div><h1>${h.t}</h1><p>${h.p}</p></div><div class="howto"><button type="button" class="xbtn" onclick="doPrint()"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 9V3h12v6M6 18H4a1 1 0 0 1-1-1v-6a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v6a1 1 0 0 1-1 1h-2"/><path d="M6 14h12v7H6z"/></svg>${p==='methodes'?'Imprimer la note':'Imprimer la carte'}</button><button type="button" class="xbtn" onclick="doCSV()"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 3v12m0 0-4-4m4 4 4-4M4 17v3h16v-3"/></svg>${p==='methodes'?'Liste des sources (CSV)':'Exporter en CSV'}</button><button type="button" aria-expanded="false"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="M9.5 9.5a2.5 2.5 0 1 1 3.5 2.3c-.6.3-1 .8-1 1.5V14M12 17h.01"/></svg>Mode d'emploi</button><div class="pop" hidden><ol>${h.s.map(x=>`<li>${x}</li>`).join('')}</ol></div></div>`;const b=document.querySelector('.howto>button:last-of-type'),pp=document.querySelector('.howto .pop');b.onclick=e=>{e.stopPropagation();pp.hidden=!pp.hidden;b.setAttribute('aria-expanded',!pp.hidden)};document.addEventListener('click',()=>{pp.hidden=true},{once:true})}

/* ----- navigation ----- */
let atlasDone=false;
function go(p){CUR=p;document.querySelectorAll('.tabs button').forEach(b=>b.setAttribute('aria-selected',b.dataset.p===p));document.querySelectorAll('.pane').forEach(x=>x.hidden=x.id!=='p-'+p);hero(p);
 if(p==='atlas'&&!atlasDone){atlasDone=true;const src=document.getElementById('atlasSrc').textContent.replace(/<\\\/script/g,'</'+'script');document.getElementById('atlasFrame').src=URL.createObjectURL(new Blob([src],{type:'text/html'}))}
 if(p==='focus'&&!window.__focusDone){window.__focusDone=1;const src=document.getElementById('atlasSrc').textContent.replace(/<\\\/script/g,'</'+'script');document.getElementById('focusFrame').src=URL.createObjectURL(new Blob([src],{type:'text/html'}))+'#focus'}
 if(p==='qpv'&&window.__qvInit)setTimeout(window.__qvInit,20);
 if(p==='adresse')setTimeout(initAdr,20);
 try{history.replaceState(null,'','#'+p)}catch(e){}}
window.setTab=t=>go({v:'qpv',a:'adresse',q:'atlas',m:'methodes'}[t]||t);
document.querySelector('.tabs').addEventListener('click',e=>{const b=e.target.closest('button');if(b)go(b.dataset.p)});

/* ----- exports : CSV et impression ----- */
let CUR='atlas';
function csvDL(name,rows){const c=v=>{if(v==null)return'';if(typeof v==='number')v=String(Math.round(v*100)/100).replace('.',',');v=String(v).replace(/<[^>]+>/g,'');return /[;"\n]/.test(v)?'"'+v.replace(/"/g,'""')+'"':v};
 const t='﻿'+rows.map(r=>r.map(c).join(';')).join('\r\n');const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([t],{type:'text/csv;charset=utf-8'}));a.download=name.replace(/[^\w\-]+/g,'_')+'.csv';document.body.appendChild(a);a.click();setTimeout(()=>{a.remove()},500)}
window.csvDL=csvDL;
let PW=null;window.addEventListener('message',e=>{const d=e.data||{};if(d.rep==='csv')csvDL('Atlas_'+d.v.name,d.v.rows);if(d.rep==='print'&&PW){PW.document.open();PW.document.write(d.v);PW.document.close();setTimeout(()=>{PW.focus();PW.print()},800)}});
function doCSV(){if(CUR==='atlas'||CUR==='focus'){document.getElementById(CUR==='focus'?'focusFrame':'atlasFrame').contentWindow.postMessage({cmd:'csv'},'*')}
 else if(CUR==='qpv'){if(window.__qvCSV){const r=window.__qvCSV();csvDL('Portrait_'+r.name,r.rows)}else alert('Choisissez d\'abord un quartier.')}
 else if(CUR==='methodes'){const t=document.querySelector('#m-sources table');csvDL('Sources_observatoire_QPV',[...t.rows].map(r=>[...r.cells].map(x=>x.textContent)))}
 else{if(window.__adrCSV){const r=window.__adrCSV();csvDL('Adresse_'+r.name,r.rows)}else alert('Choisissez d\'abord une adresse.')}}
function doPrint(){if(CUR==='atlas'||CUR==='focus'){PW=window.open('','_blank');if(!PW){alert('Autorisez les fenêtres pop-up pour imprimer.');return}PW.document.write('<p style="font-family:sans-serif">Préparation de la carte…</p>');document.getElementById(CUR==='focus'?'focusFrame':'atlasFrame').contentWindow.postMessage({cmd:'print'},'*')}
 else{document.body.dataset.print=CUR;[window.__amap,window.__qvmap].forEach(m=>m&&m.invalidateSize());setTimeout(()=>window.print(),400)}}
window.addEventListener('afterprint',()=>{delete document.body.dataset.print;[window.__amap,window.__qvmap].forEach(m=>m&&m.invalidateSize())});

function fsCtl(m){const C=L.Control.extend({options:{position:'topleft'},onAdd(){const b=L.DomUtil.create('button','fsb');b.type='button';b.innerHTML='⤢ Plein écran';b.title='Afficher la carte en plein écran (Échap pour revenir)';L.DomEvent.disableClickPropagation(b);
 b.onclick=()=>{const el=m.getContainer();document.fullscreenElement?document.exitFullscreen():(el.requestFullscreen||el.webkitRequestFullscreen).call(el)};
 document.addEventListener('fullscreenchange',()=>{b.innerHTML=document.fullscreenElement===m.getContainer()?'⤡ Quitter le plein écran':'⤢ Plein écran';setTimeout(()=>m.invalidateSize(),150)});return b}});new C().addTo(m)}
