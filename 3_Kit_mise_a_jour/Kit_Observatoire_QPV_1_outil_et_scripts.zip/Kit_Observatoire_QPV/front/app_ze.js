/* ----- zones d'emploi (Insee, ZE 2020) ----- */
const ZE=J('zeData');let ZEL=null,ZEH=null;
const ZEB=ZE.features.map(f=>{let x0=1e9,y0=1e9,x1=-1e9,y1=-1e9;(f.geometry.type==='Polygon'?[f.geometry.coordinates]:f.geometry.coordinates).forEach(p=>p[0].forEach(c=>{if(c[0]<x0)x0=c[0];if(c[0]>x1)x1=c[0];if(c[1]<y0)y0=c[1];if(c[1]>y1)y1=c[1]}));return [x0,y0,x1,y1]});
function zeAt(lat,lon){for(let i=0;i<ZE.features.length;i++){const b=ZEB[i];if(lon<b[0]||lon>b[2]||lat<b[1]||lat>b[3])continue;if(inGeo(ZE.features[i].geometry,lon,lat))return ZE.features[i]}return null}
const ZLB=L.layerGroup();
function zeTip(p){const tc=p.tc!=null?p.tc.toLocaleString('fr-FR',{minimumFractionDigits:1})+' %':'n.d.';return `<b>Zone d'emploi : ${p.n}</b><br>Code Insee ${p.c}<br>Chômage ${tc} (${ZE.periode})<br>${fr(p.ent)} entreprises · ${fr(p.pop)} habitants · ${p.nq} QPV`}
function zeLabels(){ZLB.clearLayers();if(!am||!document.getElementById('ly-z').checked)return;const z=am.getZoom();if(z<7||z>12)return;const b=am.getBounds();
 ZE.features.forEach((f,i)=>{const q=ZEB[i],la=(q[1]+q[3])/2,lo=(q[0]+q[2])/2;if(!b.contains([la,lo]))return;
  if(z<8&&f.properties.pop<150000)return;
  L.marker([la,lo],{interactive:false,icon:L.divIcon({className:'',iconSize:null,html:`<div style="transform:translate(-50%,-50%);white-space:nowrap;font:700 11.5px/1.2 var(--display,sans-serif);color:#4B3577;text-shadow:0 0 3px #fff,0 0 3px #fff,0 0 3px #fff;letter-spacing:.02em">ZE ${f.properties.n}</div>`})}).addTo(ZLB)})}
function zeLayer(){if(ZEL)return;ZEL=L.geoJSON(ZE,{style:{color:'#5B3E99',weight:2.4,opacity:.85,dashArray:'8 5',fill:true,fillOpacity:0},
 onEachFeature:(f,l)=>{l.bindTooltip(zeTip(f.properties),{sticky:true});l.on('mouseover',()=>l.setStyle({weight:4,fillColor:'#6B4FA0',fillOpacity:.07}));l.on('mouseout',()=>ZEL.resetStyle(l))}});
 ZLB.addTo(am);am.on('moveend',zeLabels);if(document.getElementById('ly-z').checked)ZEL.addTo(am);zeLabels()}
function zeHTML(pt){const f=zeAt(pt.lat,pt.lon);A.ze=f;if(ZEH){am.removeLayer(ZEH);ZEH=null}
 if(!f)return '<div class="sit" style="border:1px solid var(--line);font-size:13px;color:var(--mut)">Zone d\'emploi : non déterminée.</div>';
 const p=f.properties;ZEH=L.geoJSON(f,{style:{color:'#6B4FA0',weight:3,fill:true,fillColor:'#6B4FA0',fillOpacity:.04},interactive:false}).addTo(am);
 const tc=p.tc!=null?p.tc.toLocaleString('fr-FR',{minimumFractionDigits:1})+' %':'n.d.',dv=(p.tc!=null&&p.tc1!=null)?p.tc-p.tc1:null;
 return `<div class="sit" style="border:1px solid #DCD3EE;background:#F6F3FB"><div class="lab" data-tip="Zone d'emploi 2020 (Insee) : territoire dans lequel la plupart des actifs résident et travaillent. C'est le périmètre de référence pour le marché du travail local.">Zone d'emploi</div>
 <div style="font:800 16px/1.3 var(--display);color:#4B3577;margin-top:3px">${p.n}</div>
 <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-top:8px">
  <div data-tip="Taux de chômage localisé de la zone d'emploi, ${ZE.periode} (Insee, données corrigées des variations saisonnières). Entre parenthèses : évolution sur un an."><b style="font-size:18px;color:#4B3577">${tc}</b><div style="font-size:11.5px;color:var(--mut)">taux de chômage${dv!=null?' ('+(dv>0?'+':'')+dv.toLocaleString('fr-FR',{maximumFractionDigits:1})+' pt sur un an)':''}</div></div>
  <div data-tip="Entreprises des communes de la zone d'emploi (Insee Flores 2023)."><b style="font-size:18px;color:#4B3577">${fr(p.ent)}</b><div style="font-size:11.5px;color:var(--mut)">entreprises</div></div>
  <div data-tip="Population municipale 2020 de la zone (Insee) et nombre de quartiers prioritaires 2024."><b style="font-size:18px;color:#4B3577">${fr(p.pop)}</b><div style="font-size:11.5px;color:var(--mut)">habitants · ${p.nq} QPV</div></div></div>
 <div style="font-size:12.5px;margin-top:8px;color:#3B4557">${p.ls?`<b>${fr(p.ls)}</b> logements sociaux dont <b>${(100*p.lq/p.ls).toLocaleString('fr-FR',{maximumFractionDigits:1})} %</b> en QPV (RPLS 2024) · `:''}<b>${fr(p.att)}</b> familles logées par Action Logement en 2025.</div></div>`}
/* ----- zones d'activité économique (IGN BD TOPO, chargées à la demande) ----- */
const ZAL=L.layerGroup(),ZAC=new Map();let ZAS=new Set(),ZAT=null;
const ZAW='https://data.geopf.fr/wfs/ows?SERVICE=WFS&VERSION=2.0.0&REQUEST=GetFeature&TYPENAMES=BDTOPO_V3:zone_d_activite_ou_d_interet&OUTPUTFORMAT=application/json&COUNT=1500&CQL_FILTER=';
function zaKey(f){return f.id||(f.properties.cleabs)}
async function zaFetch(s,w,n,e){const k=[s,w,n,e].map(v=>v.toFixed(2)).join(',');if(ZAC.has(k))return ZAC.get(k);
 let r=[];try{const j=await (await fetch(ZAW+encodeURIComponent(`nature IN ('Zone industrielle','Divers commercial') AND BBOX(geometrie,${s.toFixed(5)},${w.toFixed(5)},${n.toFixed(5)},${e.toFixed(5)})`))).json();if(!j.features)throw 0;r=j.features}catch(x){r=await zaOSM(s,w,n,e)}
 ZAC.set(k,r);return r}
async function zaOSM(s,w,n,e){try{const q=`[out:json][timeout:20];(way["landuse"~"industrial|commercial|retail"](${s},${w},${n},${e}););out geom;`;
 const j=await (await fetch('https://overpass-api.de/api/interpreter',{method:'POST',body:'data='+encodeURIComponent(q)})).json();
 return j.elements.filter(x=>x.geometry).map(x=>({id:'o'+x.id,type:'Feature',properties:{nature:x.tags.landuse==='industrial'?'Zone industrielle':'Zone commerciale',toponyme:x.tags.name||null,source:'OpenStreetMap'},geometry:{type:'Polygon',coordinates:[x.geometry.map(p=>[p.lon,p.lat])]}}))}catch(x){return []}}
function zaArea(g){let a=0;(g.type==='Polygon'?[g.coordinates]:g.coordinates).forEach(p=>{const r=p[0],k=Math.cos(r[0][1]*Math.PI/180)*111.32;for(let i=0,j=r.length-1;i<r.length;j=i++){a+=(r[j][0]*k)*(r[i][1]*110.57)-(r[i][0]*k)*(r[j][1]*110.57)}});return Math.abs(a/2)*100}
const ZAN=new Set();function zaCom(c){return c?c.toLowerCase().replace(/(^|[\s-])\S/g,m=>m.toUpperCase()).replace(/ Arrondissement/,' arr.'):''}
function zaName(p){return p.toponyme?p.toponyme.charAt(0).toUpperCase()+p.toponyme.slice(1):(p.nature==='Divers commercial'?'Zone commerciale sans nom':'Zone d\'activité sans nom')}
function zaDraw(fs){if(!am.getPane('zaP')){am.createPane('zaP').style.zIndex=350;const t=am.createPane('zaT');t.style.zIndex=640;t.style.pointerEvents='none'}
 fs.forEach(f=>{const k=zaKey(f);if(ZAS.has(k))return;const p=f.properties,ha=zaArea(f.geometry);if(!p.toponyme&&ha<3)return;ZAS.add(k);
 L.geoJSON(f,{pane:'zaP',style:{color:'#8C3B0E',weight:2.2,dashArray:'2 4',fillColor:'#C2662D',fillOpacity:.1}}).bindTooltip(`<b>${zaName(p)}</b><br>${p.nature==='Divers commercial'?(p.nature_detaillee||'Zone commerciale'):'Zone d\'activité / industrielle'}${p.commune?' · '+zaCom(p.commune):''}<br>Surface ≈ ${fr(Math.round(ha))} ha<br><span style="color:#8A93A3">Source : ${p.source||'IGN BD TOPO'}</span>`,{sticky:true}).addTo(ZAL);
 if(p.toponyme&&ha>=5&&!ZAN.has(p.toponyme.toLowerCase())){ZAN.add(p.toponyme.toLowerCase());const b=L.geoJSON(f).getBounds().getCenter();L.marker(b,{pane:'zaT',interactive:false,icon:L.divIcon({className:'',iconSize:null,html:`<div style="transform:translate(-50%,-50%);white-space:nowrap;font:700 11px/1.2 var(--display,sans-serif);color:#fff;background:#8C3B0E;padding:2px 6px;border-radius:3px;opacity:.9">${zaName(p)}</div>`})}).addTo(ZAL)}})}
async function zaView(){if(!am||!document.getElementById('ly-a').checked)return;if(am.getZoom()<12){return}
 const b=am.getBounds();zaDraw(await zaFetch(b.getSouth(),b.getWest(),b.getNorth(),b.getEast()))}
function zaInit(){ZAL.addTo(am);am.on('moveend',()=>{clearTimeout(ZAT);ZAT=setTimeout(zaView,400)});const c=document.getElementById('ly-a');
 c.onchange=()=>{c.checked?(ZAL.addTo(am),zaView()):am.removeLayer(ZAL)};zaView()}
async function zaRun(pt,R){const box=document.getElementById('zabox');if(!box)return;const dl=R/111.2,dn=R/(111.2*Math.cos(pt.lat*Math.PI/180));
 const fs=await zaFetch(pt.lat-dl,pt.lon-dn,pt.lat+dl,pt.lon+dn);if(document.getElementById('ly-a').checked)zaDraw(fs);
 const L2=fs.map(f=>{let best=1e9;(f.geometry.type==='Polygon'?[f.geometry.coordinates]:f.geometry.coordinates).forEach(p=>p[0].forEach(c=>{const d=hav(pt.lat,pt.lon,c[1],c[0]);if(d<best)best=d}));
  if(inGeo(f.geometry,pt.lon,pt.lat))best=0;return {f,d:best,ha:zaArea(f.geometry)}}).filter(o=>o.d<=R&&(o.f.properties.toponyme||o.ha>=3)).sort((a,b)=>a.d-b.d||b.ha-a.ha);{const seen=new Set();for(let i=L2.length-1;i>=0;i--){}const K=[];L2.forEach(o=>{const t=o.f.properties.toponyme;if(t){const k=t.toLowerCase();if(seen.has(k))return;seen.add(k)}K.push(o)});L2.length=0;K.forEach(o=>L2.push(o))}
 A.za=L2.map(o=>[zaName(o.f.properties),o.f.properties.nature||'',Math.round(o.ha),Math.round(o.d*100)/100]);
 const ha=L2.reduce((s,o)=>s+o.ha,0);
 box.innerHTML=`<div class="lab" data-tip="Zones d'activité économique, zones industrielles et commerciales de la BD TOPO de l'IGN (catégorie « Industriel et commercial »), dans le rayon d'analyse. Distance mesurée au bord le plus proche de la zone. Si l'IGN ne répond pas, les zones viennent d'OpenStreetMap.">Zones d'activité dans le rayon</div>`+
 (L2.length?`<div style="font-size:13px;margin:4px 0 6px"><b style="font-size:18px;color:#8C3B0E">${L2.length}</b> zone${L2.length>1?'s':''} · <b>${fr(Math.round(ha))} ha</b> au total</div>`+
 '<table style="width:100%;border-collapse:collapse;font-size:12.5px"><tr style="color:var(--mut);font-size:11px;text-align:left"><th style="padding:3px 0">Zone</th><th style="text-align:right">Surface</th><th style="text-align:right">Distance</th></tr>'+L2.slice(0,5).map(o=>`<tr style="border-top:1px solid #F1E3D3"><td style="padding:5px 6px 5px 0"><b>${zaName(o.f.properties)}</b><div style="color:var(--mut);font-size:11.5px">${o.f.properties.nature==='Divers commercial'?(o.f.properties.nature_detaillee||'Commerce'):'Zone d\'activité'}${o.f.properties.commune?' · '+zaCom(o.f.properties.commune):''}</div></td><td style="text-align:right;white-space:nowrap">${fr(Math.round(o.ha))} ha</td><td style="text-align:right;white-space:nowrap;padding-left:8px">${o.d===0?'<b>sur place</b>':o.d.toLocaleString('fr-FR',{maximumFractionDigits:1})+' km'}</td></tr>`).join('')+'</table>'
 :'<div style="font-size:13px;color:var(--mut);margin-top:4px">Aucune zone d\'activité dans le rayon.</div>')}
