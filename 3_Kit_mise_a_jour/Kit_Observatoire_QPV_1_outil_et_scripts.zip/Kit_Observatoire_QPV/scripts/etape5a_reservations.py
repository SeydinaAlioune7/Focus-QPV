# Étape 5a : droits de réservation par bailleur et par territoire -> intermediaire/resa.json
# Entrées (sources/action_logement/, requêtes Power BI n°4 à 7) :
#   consommation_bailleurs.csv : SIREN, bailleur, droits attendus, familles logées 2023..2026, solde, date de fin, durée, stock restant, conso journalière moyenne
#   ancols_droits.csv          : SIREN, département, type de droits, stock au 31/12
#   flux_annuel.csv            : département, SIREN, flux annuel (logements)
#   polaris_commune.csv        : code commune, SIREN, logements réservés, nombre d'opérations
import json,collections
from config import P,lire_pbi,num
from build_points import load_points
z=lambda s:str(s).strip().split('.')[0].zfill(9)
def dep(d):
    d=d.strip().split('.')[0];return d.zfill(2) if d.isdigit() and len(d)<3 else d
nm={}
G=json.load(open(P['rpls_geo']));c=collections.defaultdict(collections.Counter)
for r in G:c[r[6]][z(r[5])]+=r[7] or 1;nm.setdefault(z(r[5]),r[6])
PT,_=load_points();bsir=[c[b].most_common(1)[0][0] if c[b] else '' for b in PT['b']]
B={}
for r in lire_pbi('consommation_bailleurs.csv'):
    s=z(r[0]);nm.setdefault(s,r[1])
    B[s]=[r[1],num(r[2]),num(r[3]),num(r[4]),num(r[5]),num(r[10]),r[9],r[8][:10],num(r[11])]
A=collections.defaultdict(lambda:[0,0])
for r in lire_pbi('ancols_droits.csv'):
    A[(z(r[0]),dep(r[1]))][1 if 'à livrer' in r[2] else 0]+=num(r[3]) or 0
F={}
for r in lire_pbi('flux_annuel.csv'):
    if r[0].strip():F[(z(r[1]),dep(r[0]))]=num(r[2]) or 0
Rr=[[r[0].split('.')[0].zfill(5),z(r[1]),int(num(r[2]) or 0),int(num(r[3]) or 0)] for r in lire_pbi('polaris_commune.csv') if r[0].strip()]
keys=sorted(set(A)|set(F))
out={'B':B,'N':{s:nm[s] for s in set([k[0] for k in keys]+[r[1] for r in Rr]+list(B)) if s in nm},
 'A':[[k[0],k[1],round(A[k][0]) if k in A else 0,round(A[k][1]) if k in A else 0,F.get(k)] for k in keys],'R':Rr,'bs':bsir}
json.dump(out,open(P['resa'],'w'),ensure_ascii=False,separators=(',',':'))
print('bailleurs (consommation)',len(B),'· lignes droits',len(out['A']),'· lignes POLARIS',len(Rr),'· droits en stock',round(sum(a[2] for a in out['A'])))
