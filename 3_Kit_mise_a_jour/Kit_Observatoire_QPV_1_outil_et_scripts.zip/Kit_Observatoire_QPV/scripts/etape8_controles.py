# Étape 8 : contrôles de fiabilité des données de l'outil.
# Compare chaque donnée affichée à sa source, vérifie les bornes et les cohérences.
# Lancer : python etape8_controles.py   -> écrit sortie/controles_fiabilite.txt
import json, csv, os, math, sys
from collections import defaultdict
sys.path.insert(0, os.path.dirname(__file__))
from config import P, lire_pbi, num

L = []; NB = {'OK': 0, 'ALERTE': 0, 'INFO': 0}
def res(niveau, theme, msg):
    NB[niveau] += 1; L.append(f'[{niveau:6}] {theme:22} {msg}')
def eq(theme, nom, a, b, tol=0.0):
    ok = (a == b) if tol == 0 else (abs(a - b) <= tol * max(abs(b), 1))
    res('OK' if ok else 'ALERTE', theme, f'{nom} : outil {a:,.0f} / source {b:,.0f}'.replace(',', ' '))
def J(n): return json.load(open(P['mid'] + n, encoding='utf-8'))
def FR(lat, lon):  # emprise France + DOM
    return (41 <= lat <= 51.5 and -5.5 <= lon <= 10) or (-22 <= lat <= 18.5 and (-62 <= lon <= -51 or 44 <= lon <= 56)) or (-18 <= lat <= -16 and -150 <= lon <= -149)

# ---------- 1. Parc social RPLS 2024 (atlas) ----------
D = J('data_c.json'); S = D['S']; codes = D['U']['c']
src = defaultdict(lambda: [0] * 9)
for r in csv.DictReader(open(P['pbi'] + 'rpls_par_commune.csv', encoding='utf-8-sig')):
    for i, k in enumerate(['tot', 'qpv', 'fg', 'e', 'et', 'vac', 'fgq', 'etq', 'vacq']): src[r['depcom']][i] += num(r[k]) or 0
sansc = src.pop('', [0] * 9)
tot_src = sum(v[0] for v in src.values())
eq('RPLS 2024', 'logements sociaux (communes codées)', sum(S['tot']), tot_src, 0.001)
eq('RPLS 2024', 'dont en QPV', sum(S['qpv']), sum(v[1] for v in src.values()), 0.001)
eq('RPLS 2024', 'étiquettes F ou G', sum(S['fg']), sum(v[2] for v in src.values()), 0.001)
eq('RPLS 2024', 'logements vacants', sum(S['vac']), sum(v[5] for v in src.values()), 0.001)
res('INFO', 'RPLS 2024', f'{sansc[0]:,.0f} logements sans code commune dans RPLS (non cartographiables, {100*sansc[0]/(tot_src+sansc[0]):.2f} % du parc)'.replace(',', ' '))
inc = [codes[i] for i in range(len(codes)) if S['qpv'][i] > S['tot'][i] or S['fg'][i] > S['et'][i] or S['et'][i] > S['tot'][i] or S['vac'][i] > S['tot'][i]]
res('OK' if not inc else 'ALERTE', 'RPLS 2024', f'cohérence par commune (QPV, F/G, vacants <= total) : {len(inc)} commune(s) incohérente(s) {inc[:5]}')
gap = tot_src - sum(S['tot'])
res('OK' if gap < 0.001 * tot_src else 'ALERTE', 'RPLS 2024', f'{gap:,.0f} logements à des codes commune sans contour (anciennes communes fusionnées), soit {100*gap/tot_src:.3f} %'.replace(',', ' '))

# ---------- 2. Attributions 2025 ----------
att_src = sum(num(r[1]) or 0 for r in lire_pbi('attributions_commune.csv'))
eq('Attributions 2025', 'familles logées (atlas)', sum(S['att']), att_src, 0.003)
res('INFO', 'Attributions 2025', f'{att_src - sum(S["att"]):,.0f} familles rattachées à un code commune sans contour (Marseille sans arrondissement, communes fusionnées)'.replace(',', ' '))

# ---------- 3. Population et QPV ----------
ref = D['ref']; res('INFO', 'Population', f"population totale {ref['pop']:,} · en QPV {ref['q']:,} ({100*ref['q']/ref['pop']:.1f} %)".replace(',', ' '))
Q = J('qpv_portrait.json')['Q']
G = {f['properties']['code_qp'] for f in json.load(open(P['qpv_dir'] + 'QP2024_France_Hexagonale_Outre_Mer_WGS84.geojson', encoding='utf-8'))['features']}
sans = sorted(set(Q) - G); sansd = sorted(G - set(Q))
res('OK' if len(G) == 1584 else 'ALERTE', 'QPV 2024', f'{len(G)} contours ANCT (référence : 1 584)')
res('INFO' if all(k.startswith('QN976') for k in sans + sansd) else 'ALERTE', 'QPV 2024', f'{len(Q)} quartiers avec données Insee ; {len(sans)} sans contour et {len(sansd)} contours sans données Insee, tous à Mayotte (codes Insee « M » de l\'ancienne liste, contours ANCT « C » de la nouvelle)')
popq = {}
for r in csv.reader(open(P['pop_qpv'], encoding='utf-8-sig'), delimiter=';'):
    if len(r) > 1 and num(r[-1]) is not None: popq[r[0]] = num(r[-1])
if popq:
    diff = [k for k, q in Q.items() if k in popq and q.get('pop') is not None and abs(q['pop'] - popq[k]) > 1]
    res('OK' if not diff else 'ALERTE', 'QPV 2024', f'population par QPV identique au fichier Insee : {len(diff)} écart(s) {diff[:5]}')
hors = defaultdict(list)
for k, q in Q.items():
    for ind, v in (q.get('i') or {}).items():
        if v is None: continue
        if (ind.startswith('part') or ind.startswith('tx')) and not (0 <= v <= 100): hors[ind].append(k)
res('OK' if not hors else 'ALERTE', 'Portrait QPV', 'parts et taux entre 0 et 100 % : ' + ('tous conformes' if not hors else str({k: len(v) for k, v in hors.items()})))
som = []
for k, q in Q.items():
    i = q.get('i') or {}; a = [i.get(x) for x in ('partPop0_14', 'partPop15_24', 'partPop25_59', 'partPop60_74', 'partPop75p')]
    if None not in a and abs(sum(a) - 100) > 1.5: som.append(k)
res('OK' if not som else 'ALERTE', 'Portrait QPV', f'tranches d\'âge sommant à 100 % (±1,5) : {len(som)} écart(s) {som[:5]}')

# ---------- 4. Droits de réservation et durée d'écoulement ----------
R = J('resa.json'); B = R['B']
c_src = {r[0].zfill(9): r for r in lire_pbi('consommation_bailleurs.csv')}
eq('Réservations', 'bailleurs dans le fichier de consommation', len(B), len(c_src))
ec = [s for s, b in B.items() if s in c_src and (num(c_src[s][10]) or 0) != (b[5] or 0)]
res('OK' if not ec else 'ALERTE', 'Réservations', f'stock restant identique à la source : {len(ec)} écart(s) {ec[:5]}')
ext = [s for s, b in B.items() if b[5] and b[8] and b[5] / (b[8] * 365) > 30]
res('INFO', 'Écoulement', f'{len(ext)} bailleurs à plus de 30 ans (affichés « Plus de 30 ans ») : stock élevé et consommation quasi nulle, pas une erreur de calcul')
an = defaultdict(float)
for r in lire_pbi('ancols_droits.csv'): an[r[2]] += num(r[3]) or 0
res('INFO', 'Réservations', 'droits ANCOLS 2025 par type : ' + ' · '.join(f'{k} {v:,.0f}'.replace(',', ' ') for k, v in an.items()))

# ---------- 5. Programmes réservés (POLARIS) ----------
O = J('ops.json')['r']; ps = lire_pbi('polaris_operations.csv')
tot_ops = sum(num(r[6]) or 0 for r in ps if (num(r[6]) or 0) > 0)
res('INFO', 'Programmes', f'{len(O):,} programmes placés sur {len([r for r in ps if (num(r[6]) or 0)>0]):,} ({sum(o[2] for o in O):,.0f} logements réservés sur {tot_ops:,.0f})'.replace(',', ' '))
hz = [o for o in O if not FR(o[0], o[1])]
res('OK' if not hz else 'ALERTE', 'Programmes', f'coordonnées en France : {len(hz)} hors emprise')

# ---------- 6. Repères : gares, pôles, communes ----------
OB = J('obs_small.json')
hz = [g[0] for g in OB['GARES'] if not FR(g[1], g[2])]
res('OK' if not hz else 'ALERTE', 'Gares', f'{len(OB["GARES"])} gares, {len(hz)} hors emprise {hz[:5]}')
dup = len(OB['GARES']) - len({(g[0], round(g[1], 3), round(g[2], 3)) for g in OB['GARES']})
res('OK' if dup == 0 else 'INFO', 'Gares', f'{dup} doublon(s) nom + position')
res('OK' if all(p[4] >= 5000 for p in OB['POLES']) else 'ALERTE', 'Pôles d\'emploi', f'{len(OB["POLES"])} communes de plus de 5 000 entreprises')

# ---------- 7. Zones d'emploi ----------
Z = J('ze_geo.json')['features']; pz = [f['properties'] for f in Z]
res('OK' if 300 <= len(Z) <= 310 else 'ALERTE', 'Zones d\'emploi', f'{len(Z)} zones (ZE2020 France entière : 306 hors Mayotte et Polynésie)')
tc = [p['tc'] for p in pz if p.get('tc') is not None]
res('OK' if tc and min(tc) >= 2 and max(tc) <= 35 else 'ALERTE', 'Zones d\'emploi', f'taux de chômage entre {min(tc)} et {max(tc)} % ({len(tc)} zones renseignées, {len(Z)-len(tc)} sans taux)')
eq('Zones d\'emploi', 'logements sociaux (somme des zones)', sum(p.get('ls') or 0 for p in pz), tot_src, 0.01)
eq('Zones d\'emploi', 'familles logées 2025 (somme des zones)', sum(p.get('att') or 0 for p in pz), att_src, 0.01)
eq('Zones d\'emploi', 'population (somme des zones)', sum(p.get('pop') or 0 for p in pz), ref['pop'], 0.02)

# ---------- 8. Évolutions ----------
E = J('evol.json'); r23 = {r[0]: num(r[1]) for r in lire_pbi('rpls2023_commune.csv') if r[0]}
r24 = {r[0]: num(r[1]) for r in lire_pbi('rpls2024_commune.csv') if r[0]}
ec = [c for c, v in E.items() if c in r24 and r24[c] is not None and abs(v[3] - r24[c]) > 0]
res('OK' if not ec else 'ALERTE', 'Évolutions', f'parc 2024 par commune identique à la source : {len(ec)} écart(s) {ec[:5]}')

# ---------- 9. Géolocalisation des adresses du parc social ----------
G9 = json.load(open(P['rpls_geo'], encoding='utf-8'))
m = defaultdict(float); tg = 0
for r in G9: m[r[12] or 'non localisée'] += r[7]; tg += r[7]
eq('Géolocalisation', 'logements dans le fichier géolocalisé', tg, tot_src + sansc[0], 0.005)
res('INFO', 'Géolocalisation', 'précision (en logements) : ' + ' · '.join(f'{k} {100*v/tg:.1f} %' for k, v in sorted(m.items(), key=lambda x: -x[1])))
try:
    import random
    from shapely.geometry import shape, Point
    from shapely.strtree import STRtree
    from pyproj import Transformer
    tr = Transformer.from_crs(2154, 4326, always_xy=True)
    com = {}
    for f in json.load(open(P['communes_geo'], encoding='utf-8'))['features']: com[f['properties'].get('code')] = shape(f['geometry'])
    for f in json.load(open(P['arr_geo'], encoding='utf-8'))['features']: com[f['properties'].get('code')] = shape(f['geometry'])
    random.seed(1); smp = [r for r in random.sample(G9, 20000) if r[13] and r[0] in com and r[0][:2] not in ('97',)]
    hors = 0
    for r in smp:
        lon, lat = tr.transform(r[13], r[14])
        if not com[r[0]].buffer(0.01).contains(Point(lon, lat)): hors += 1
    res('OK' if hors / len(smp) < 0.01 else 'ALERTE', 'Géolocalisation', f'échantillon de {len(smp):,} adresses : {hors} hors de leur commune (marge 1 km), soit {100*hors/len(smp):.2f} %'.replace(',', ' '))
except Exception as e:
    res('INFO', 'Géolocalisation', f'test commune non réalisé ({e})')

# ---------- Synthèse ----------
txt = f"Contrôles de fiabilité · {NB['OK']} OK · {NB['ALERTE']} alerte(s) · {NB['INFO']} information(s)\n\n" + '\n'.join(L)
open(P['out'] + 'controles_fiabilite.txt', 'w', encoding='utf-8').write(txt); print(txt)
