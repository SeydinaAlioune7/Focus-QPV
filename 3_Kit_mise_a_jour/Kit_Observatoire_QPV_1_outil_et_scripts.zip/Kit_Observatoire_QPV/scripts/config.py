# Chemins du kit. Tout est relatif au dossier du kit : ne changer que si vous déplacez des fichiers.
import os
R=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))   # racine du kit
def k(*a):return os.path.join(R,*a)
P={
 # sources publiques
 'cog2022':k('sources','cog','communes_2022.json'),          # @etalab/decoupage-administratif 2.3.0 (pop. légales 2020)
 'cog2026':k('sources','cog','communes_2026.json'),          # @etalab/decoupage-administratif 6.0.0
 'epci2026':k('sources','cog','epci_2026.json'),
 'dep_dr':k('sources','dep_dr.json'),                         # département -> DR Action Logement
 'pop_ref':k('sources','insee','pop_reference_communales_QPV24.csv'),
 'pop_qpv':k('sources','insee','pop_QPV24.csv'),
 'insee_dir':k('sources','insee')+os.sep,                     # dossiers Insee QPV dézippés (estimations, revenus, DEFM, CAF, EDUC, DNB, SIDE, RPLS)
 'qpv_dir':k('sources','qpv')+os.sep,                         # contours QPV 2024 (ANCT), un geojson par territoire
 'communes_geo':k('sources','communes','communes_france_geoapi_simpl.geojson'),
 'arr_geo':k('sources','communes','arrondissements_PLM_geoapi.geojson'),
 'annuaire':k('sources','education','fr-en-annuaire-education.csv'),
 'gares':k('sources','gares','gares.csv'),                    # export Power BI table Gares (nom;lat;lon;uic)
 'communes_coord':k('sources','communes','communes_coordonnees.csv'),  # export Power BI (code;lat;lon;pop;entreprises)
 'ze_dir':k('sources','zones_emploi')+os.sep,
 'ze':k('intermediaire','ze_geo.json'),
 'ban_dir':k('sources','ban')+os.sep,                         # adresses-with-ids-XX.csv.gz (adresse.data.gouv.fr)
 # exports Power BI (requetes_power_bi.dax), au format CSV
 'pbi':k('sources','action_logement')+os.sep,
 # données intermédiaires
 'mid':k('intermediaire')+os.sep,
 'data_json':k('intermediaire','data.json'),
 'data_c':k('intermediaire','data_c.json'),
 'rpls_fr':k('intermediaire','rpls_fr.json'),
 'rpls_geo':k('intermediaire','rpls_fr_geo.json'),
 'points':k('intermediaire','rpls_pts.json'),
 'portrait':k('intermediaire','qpv_portrait.json'),
 'qpv_simpl':k('intermediaire','qpv_wgs_simpl.json'),
 'obs':k('intermediaire','obs_small.json'),
 'resa':k('intermediaire','resa.json'),
 'evol':k('intermediaire','evol.json'),
 'ops_geo':k('intermediaire','ops_geo.json'),
 'ops':k('intermediaire','ops.json'),
 'atlas_html':k('intermediaire','atlas_qpv.html'),
 # code de l'outil et sorties
 'front':k('front')+os.sep,
 'out':k('sortie')+os.sep,
}

for _d in (P['out'],P['mid'],P['ban_dir']):os.makedirs(_d,exist_ok=True)

def lire_pbi(nom):
    """Lit un export CSV de requête DAX (DAX Studio ou copier-coller Excel) : séparateur ; ou , détecté, en-tête ignoré."""
    import csv
    f=open(P['pbi']+nom,encoding='utf-8-sig');first=f.readline();f.seek(0)
    sep=';' if first.count(';')>first.count(',') else ('\t' if first.count('\t')>first.count(',') else ',')
    r=list(csv.reader(f,delimiter=sep));return [[x.strip() for x in l] for l in r[1:] if l]
def num(x):
    try:return float(str(x).replace(' ','').replace(' ','').replace(',','.'))
    except:return None
