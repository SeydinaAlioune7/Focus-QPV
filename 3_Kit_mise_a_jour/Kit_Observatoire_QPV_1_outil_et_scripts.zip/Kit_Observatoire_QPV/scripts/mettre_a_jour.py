# Lance la mise à jour complète ou partielle de l'Observatoire.
#   python mettre_a_jour.py                 -> toutes les étapes (hors géocodages longs si leurs sources n'ont pas changé)
#   python mettre_a_jour.py 1 4 7           -> seulement les étapes 1, 4 et 7
#   python mettre_a_jour.py 7 --dr "DR IDF" -> assemble aussi la version de démonstration d'une DR
import subprocess,sys,os,time,datetime
from config import P
ETAPES={
 '1':['etape1a_atlas_geometries.py','etape1b_atlas_compacter.py','etape1c_atlas_indicateurs.py'],
 '2':['etape2_geocodage_rpls.py'],
 '3':['build_points.py','etape1c_atlas_indicateurs.py'],
 '4':['etape4a_portrait_insee.py','etape4b_portrait_communes.py','etape4c_portrait_ecoles_bailleurs.py'],
 '5':['etape5a_reservations.py','etape5b_programmes_reserves.py','etape5c_evolutions.py'],
 '6':['etape6_reperes.py','etape6b_zones_emploi.py'],
 '7':['etape7a_assembler.py'],
 '8':['etape8_controles.py'],
}
NOMS={'1':'Atlas : communes, QPV, population, parc social, attributions','2':'Géolocalisation du parc social (long : 30 à 60 min)',
 '3':'Points du parc social pour l\'onglet Adresse','4':'Portrait des quartiers','5':'Réservations, programmes, évolutions',
 '6':'Repères (gares, pôles d\'emploi) et contours QPV','7':'Assemblage du fichier HTML','8':'Contrôles de fiabilité (sortie/controles_fiabilite.txt)'}
args=[a for a in sys.argv[1:] if not a.startswith('--')];dr=None
if '--dr' in sys.argv:dr=sys.argv[sys.argv.index('--dr')+1];args=[a for a in args if a!=dr]
choix=args or ['1','4','5','6','7','8']
here=os.path.dirname(os.path.abspath(__file__));log=open(os.path.join(P['out'],'journal_mise_a_jour.txt'),'a',encoding='utf-8')
log.write('\n=== '+datetime.datetime.now().strftime('%d/%m/%Y %H:%M')+' · étapes '+' '.join(choix)+(' · DR '+dr if dr else '')+'\n')
for e in choix:
    print('\n### Étape',e,':',NOMS[e])
    for s in ETAPES[e]:
        t=time.time();print('   ->',s,flush=True)
        r=subprocess.run([sys.executable,s],cwd=here,capture_output=True,text=True)
        print(r.stdout[-1500:]);log.write(s+'\n'+r.stdout[-3000:]+'\n')
        if r.returncode:
            print(r.stderr[-3000:]);log.write('ERREUR\n'+r.stderr[-3000:]);sys.exit('Arrêt : '+s+' a échoué. Voir le message ci-dessus et la section « En cas de problème » du LISEZMOI.')
        print('   ok en',round(time.time()-t),'s')
if dr:
    r=subprocess.run([sys.executable,'etape7b_version_dr.py',dr],cwd=here,capture_output=True,text=True);print(r.stdout[-800:],r.stderr[-1500:])
print('\nTerminé. Fichiers dans',P['out'])
