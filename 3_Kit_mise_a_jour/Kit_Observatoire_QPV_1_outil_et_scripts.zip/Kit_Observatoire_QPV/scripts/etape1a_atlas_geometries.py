# Étape 1a : communes, QPV, population en QPV -> intermediaire/data.json
# Durée : quelques minutes. Paquets : shapely, pyproj.
import json, csv, collections, sys
from shapely.geometry import shape, mapping
from shapely.ops import transform, unary_union
from pyproj import Transformer

from config import P

# ---------- référentiels ----------
c22 = json.load(open(P['cog2022']))      # COG 2022, pop légales 2020
c26 = json.load(open(P['cog2026']))      # COG 2026
e26 = json.load(open(P['epci2026']))
dep_dr = json.load(open(P['dep_dr']))

pop20 = {}
for x in c22:
    if x['type'] in ('commune-actuelle', 'arrondissement-municipal'):
        pop20[x['code']] = x.get('population') or 0
act26 = {x['code']: x for x in c26 if x['type'] == 'commune-actuelle'}
arr26 = {x['code']: x for x in c26 if x['type'] == 'arrondissement-municipal'}
chef26 = {}
for x in c26:
    if x['type'] in ('commune-deleguee', 'commune-associee') and x.get('chefLieu'):
        chef26.setdefault(x['code'], x['chefLieu'])

PLM = {'75056', '13055', '69123'}

def to26(code):
    if code in act26 or code in arr26:
        return code
    if code in chef26:
        return chef26[code]
    return None

# population 2020 ramenée sur la géographie 2026 (unités : communes, arrondissements pour PLM)
pop = collections.Counter(); unmapped_pop = []
for code, p in pop20.items():
    if code in PLM:
        continue  # on compte via les arrondissements
    t = to26(code)
    if t is None:
        unmapped_pop.append((code, p)); continue
    pop[t] += p

# population en QPV (Insee, géographie 2022)
qpv = collections.Counter(); unmapped_q = []; hors = collections.Counter()
for r in csv.DictReader(open(P['pop_ref'],encoding='utf-8-sig')):
    code = r['codeDepcom']; p = int(r['popMuniQPV'])
    if r['codeDep'] in ('978', '987'):
        hors[r['codeDep']] += p; continue
    t = to26(code)
    if t is None:
        unmapped_q.append((code, r['libDepcom'], p)); continue
    qpv[t] += p
print('pop non rattachée', len(unmapped_pop), sum(p for _, p in unmapped_pop), unmapped_pop[:10])
print('qpv non rattachée', unmapped_q)
print('hors champ (978/987)', dict(hors))

# EPCI 2026
epci_of = {}; epci_nom = {}
for e in e26:
    epci_nom[e['code']] = e['nom']
    for m in e['membres']:
        epci_of[m['code']] = e['code']

def dr_of(dep):
    if dep.startswith('97'):
        return 'DR DROM'
    return dep_dr.get(dep, (None, None))[1]

# ---------- géométries ----------
ZONES = {  # zone -> EPSG
    'M': 2154, '971': 5490, '972': 5490, '973': 2972, '974': 2975, '976': 4471}
TR = {z: Transformer.from_crs(4326, e, always_xy=True) for z, e in ZONES.items()}
def zone_of(dep):
    return dep if dep in ZONES else 'M'

UNIT = 10.0  # 10 m (unité des boîtes et points)
ALPH = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_'
def venc(v):
    v = (v << 1) ^ (v >> 63)  # zigzag
    v &= (1 << 64) - 1
    out = ''
    while True:
        b = v & 31; v >>= 5
        if v: out += ALPH[b | 32]
        else:
            out += ALPH[b]; return out
def encode(geom, unit=None):
    unit = unit or UNIT
    """Polygon/MultiPolygon projeté -> liste de polygones -> anneaux en entiers delta"""
    polys = [geom] if geom.geom_type == 'Polygon' else list(geom.geoms)
    out = []
    for p in polys:
        rings = [p.exterior] + list(p.interiors)
        enc = []
        for r in rings:
            pts = [(round(x / unit), round(y / unit)) for x, y in r.coords[:-1]]
            ded = []
            for q in pts:
                if not ded or q != ded[-1]:
                    ded.append(q)
            if len(ded) < 3:
                continue
            flat = [ded[0][0], ded[0][1]]
            for a, b in zip(ded, ded[1:]):
                flat += [b[0] - a[0], b[1] - a[1]]
            enc.append(''.join(venc(v) for v in flat))
        if enc:
            out.append(enc)
    return out

def proj(g, z):
    t = TR[z]
    return transform(lambda x, y, zz=None: t.transform(x, y), g)

feat = json.load(open(P['communes_geo']))['features']
arrs = json.load(open(P['arr_geo']))['features']

units = []   # unités colorées
outlines = []  # contours des villes PLM
bbox = {}
TOL = 45
CU = 20.0
for f in feat:
    code = f['properties']['code']; nom = f['properties']['nom']
    c = act26.get(code)
    dep = c['departement'] if c else code[:2]
    z = zone_of(dep)
    g = proj(shape(f['geometry']), z).buffer(0).simplify(TOL, preserve_topology=True)
    if code in PLM:
        outlines.append({'c': code, 'n': nom, 'z': z, 'g': encode(g, CU)})
        continue
    units.append({'c': code, 'n': nom, 'd': dep, 'z': z, 'e': epci_of.get(code), 'g': encode(g, CU), 'geom': g})
for f in arrs:
    code = f['properties']['code']; parent = f['properties']['codeParent']
    nom = f['properties']['nom'].replace(' Arrondissement', '')
    dep = parent[:2]
    g = proj(shape(f['geometry']), 'M').buffer(0).simplify(TOL, preserve_topology=True)
    units.append({'c': code, 'n': nom, 'd': dep, 'z': 'M', 'e': epci_of.get(parent), 'g': encode(g, CU), 'geom': g, 'p': parent})

# QPV
qf = json.load(open(P['qpv_dir']+'QP2024_France_Hexagonale_Outre_Mer_WGS84.geojson'))['features']
qout = []
for f in qf:
    pr = f['properties']; dep = pr['insee_dep']
    if dep in ('978', '987'):
        continue
    z = zone_of(dep)
    g = proj(shape(f['geometry']), z).buffer(0).simplify(8, preserve_topology=True)
    qout.append({'q': pr['code_qp'], 'n': pr['lib_qp'], 'c': pr['insee_com'], 'lc': pr['lib_com'], 'd': dep, 'z': z, 'g': encode(g, 5.0)})

# ---------- indicateurs ----------
codes_units = {u['c'] for u in units}
miss_pop = [u['c'] for u in units if u['c'] not in pop]
print('unités sans pop 2020:', len(miss_pop), miss_pop[:15])
miss_geo = [(k, v) for k, v in qpv.items() if k not in codes_units]
print('pop QPV sans géométrie:', miss_geo)

out_units = []
for u in units:
    p = pop.get(u['c']); q = qpv.get(u['c'], 0)
    x0, y0, x1, y1 = u['geom'].bounds
    rp = u['geom'].representative_point()
    out_units.append({'c': u['c'], 'n': u['n'], 'd': u['d'], 'z': u['z'], 'e': u['e'], 'p': p, 'q': q,
                      'b': [round(x0/UNIT), round(y0/UNIT), round(x1/UNIT), round(y1/UNIT)],
                      'l': [round(rp.x/UNIT), round(rp.y/UNIT)], 'g': u['g'], **({'pa': u['p']} if 'p' in u else {})})

# totaux
tot_pop = sum(u['p'] or 0 for u in out_units); tot_q = sum(u['q'] for u in out_units)
print('France (101 dép.) pop 2020', tot_pop, 'pop QPV', tot_q, 'part', round(100*tot_q/tot_pop, 2))
metro = [u for u in out_units if u['z'] == 'M']
mp = sum(u['p'] or 0 for u in metro); mq = sum(u['q'] for u in metro)
print('Hexagone', mp, mq, round(100*mq/mp, 2))

deps = {}
for c in c26:
    pass
dep_names = {k: v[0] for k, v in dep_dr.items()}
dep_names.update({'971': 'Guadeloupe', '972': 'Martinique', '973': 'Guyane', '974': 'La Réunion', '976': 'Mayotte'})
used_epci = sorted({u['e'] for u in out_units if u['e']})
data = {
    'unit': UNIT, 'cu': CU, 'qu': 5.0,
    'units': out_units,
    'outlines': outlines,
    'qpv': qout,
    'epci': {e: epci_nom[e] for e in used_epci},
    'dep': {d: [dep_names.get(d, d), dr_of(d)] for d in sorted({u['d'] for u in out_units})},
    'ref': {'pop': tot_pop, 'q': tot_q, 'hors': dict(hors)},
}
s = json.dumps(data, ensure_ascii=False, separators=(',', ':'))
open(P['data_json'], 'w').write(s)
print('taille', len(s)/1e6, 'Mo', 'units', len(out_units), 'qpv', len(qout))
