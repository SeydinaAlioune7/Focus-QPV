# Étape 6 : repères de l'onglet Adresse (gares, communes, pôles d'emploi) et contours QPV simplifiés pour le web.
# Entrées : sources/gares/gares.csv (requête 12), sources/communes/communes_coordonnees.csv (13), contours QPV WGS84.
import json
from config import P,num
import csv
def lire(p):
    f=open(p,encoding='utf-8-sig');first=f.readline();f.seek(0);sep=';' if first.count(';')>first.count(',') else ','
    r=list(csv.reader(f,delimiter=sep));return r[1:]
cog={x['code']:x['nom'] for x in json.load(open(P['cog2026'])) if x['type']=='commune-actuelle'}
G=[[r[0],round(num(r[1]),5),round(num(r[2]),5),r[3].split('.')[0].zfill(5)] for r in lire(P['gares']) if num(r[1]) and num(r[2])]
C=[[r[0].split('.')[0].zfill(5),round(num(r[1]),3),round(num(r[2]),3),int(num(r[3]) or 0),int(num(r[4]) or 0)] for r in lire(P['communes_coord']) if num(r[1])]
SEUIL=5000   # pôle d'emploi = commune de plus de 5 000 entreprises (Flores)
PO=sorted([[c[0],cog.get(c[0],c[0]),c[1],c[2],c[4]] for c in C if c[4]>SEUIL],key=lambda x:-x[4])
json.dump({'GARES':G,'POLES':PO,'COMMUNES':C},open(P['obs'],'w'),ensure_ascii=False,separators=(',',':'))
print('gares',len(G),'communes',len(C),'pôles',len(PO))
from shapely.geometry import shape,mapping
F=json.load(open(P['qpv_dir']+'QP2024_France_Hexagonale_Outre_Mer_WGS84.geojson'))['features'];out=[]
def rnd(o):
    if isinstance(o,(list,tuple)):
        return [rnd(x) for x in o] if o and isinstance(o[0],(list,tuple)) else [round(o[0],5),round(o[1],5)]
for f in F:
    g=shape(f['geometry']).simplify(0.00005,preserve_topology=True);m=mapping(g)
    out.append({'type':'Feature','properties':{'code_qp':f['properties']['code_qp'],'lib_qp':f['properties']['lib_qp']},'geometry':{'type':m['type'],'coordinates':rnd(m['coordinates'])}})
json.dump({'type':'FeatureCollection','features':out},open(P['qpv_simpl'],'w'),ensure_ascii=False,separators=(',',':'))
print('QPV',len(out))
