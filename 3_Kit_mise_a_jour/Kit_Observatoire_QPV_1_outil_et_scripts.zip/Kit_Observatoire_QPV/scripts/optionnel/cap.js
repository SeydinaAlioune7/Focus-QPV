const {chromium}=require('playwright');const fs=require('fs');(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:{width:1500,height:1100}});p.on('pageerror',e=>console.log('E',e.message));
await p.goto('file://'+process.cwd()+'/observatoire_qpv_entreprise.html#focus');await p.waitForTimeout(10000);
const f=p.frames().find(x=>x.url().startsWith('blob')&&x.url().includes('#focus'));
await f.evaluate(()=>{document.getElementById('lv-r').click()});await p.waitForTimeout(1500);
await f.evaluate(()=>{const q=document.getElementById('q');q.value='DR IDF';q.dispatchEvent(new Event('change'));q.dispatchEvent(new Event('input'))});await p.waitForTimeout(3000);
const out={css:await f.evaluate(()=>[...document.querySelectorAll('style')].map(s=>s.textContent).join('\n')),P:{}};
for(const s of ['geo','pop','part','nb','parc']){await f.evaluate(s=>document.querySelector('#poster .styles button[data-s='+s+']').click(),s);await p.waitForTimeout(1500);out.P[s]=await f.evaluate(()=>document.getElementById('poster').outerHTML);console.log(s,out.P[s].length, await f.evaluate(()=>document.querySelector('#poster h1').textContent))}
out.resa=await f.evaluate(()=>{const r=__resaRows();const e=__evolTot();return {rows:r.slice(0,15).map(o=>[o.n,o.res,o.dis,o.liv,o.flux,DURF(o.b).l,DURF(o.b).t]),tot:r.reduce((a,o)=>[a[0]+o.res,a[1]+o.dis,a[2]+o.liv,a[3]+(o.flux||0)],[0,0,0,0]),ev:e,csv:__csv().rows}});
fs.writeFileSync('idf_cap.json',JSON.stringify(out));await b.close()})();
