# Étape 4a : indicateurs Insee par QPV (fichiers Insee QPV dézippés dans sources/insee/) -> intermediaire/qpv_portrait.json
import csv,json,collections
from shapely.geometry import shape,Point
from shapely.strtree import STRtree
from pyproj import Transformer
from config import P as CFG
I=CFG['insee_dir']
def rd(f,key):
    out={}
    for r in csv.DictReader(open(I+f,encoding='utf-8-sig',errors='replace'),delimiter=';'):
        out[r[key]]=r
    return out
def num(v):
    if v is None:return None
    v=v.strip().replace(',','.')
    if v in('','s','nd','NA','ns'):return None
    try:return float(v)
    except:return None
EST=rd('estimations-demographiques_2022_QPV2024_csv/data_donnees_quartiers.csv','codeGeo')
ESTR=rd('estimations-demographiques_2022_QPV2024_csv/data_donnees_regions.csv','codeGeo')
REV=rd('revenus_pauvrete_2021_qp24_v2_csv/data_indic-revenu-disponible-qp24-2021_v2_QP24.csv','CODGEO')
REVE=rd('revenus_pauvrete_2021_qp24_v2_csv/data_indic-revenu-disponible-qp24-2021_v2_ENSQP24.csv','CODGEO')
DEF=rd('DEFM2024_QP24_csv/data_DEFM2024_qp.csv','CODGEO')
DEFE={r['NIVGEO']:r for r in csv.DictReader(open(I+'DEFM2024_QP24_csv/data_DEFM2024_ensemble_qpv.csv',encoding='utf-8-sig'),delimiter=';')}
CAF=rd('beneficiaires_CAF_31-12-2024_QP24/data_CAF2024_QP24.csv','CODGEO')
CAFE={r['NIVGEO']:r for r in csv.DictReader(open(I+'beneficiaires_CAF_31-12-2024_QP24/data_CAF2024_ENSQP24.csv',encoding='utf-8-sig'),delimiter=';')}
EDU=rd('EDUC_2024_2025_QP24/data_EDUC_2024_2025_qp.csv','CODGEO')
EDUE={r['NIVGEO']:r for r in csv.DictReader(open(I+'EDUC_2024_2025_QP24/data_EDUC_2024_2025_ensemble.csv',encoding='utf-8-sig'),delimiter=';')}
DNB=rd('DNB_2025_QP24/data_DNB_2025_qp.csv','CODGEO')
DNBE={r['NIVGEO']:r for r in csv.DictReader(open(I+'DNB_2025_QP24/data_DNB_2025_ensemble.csv',encoding='utf-8-sig'),delimiter=';')}
SID=rd('side_2023_QPV2024/data_side_2023_QPV2024_QP.csv','CODGEO')
RP=rd('RPLS_01-01-2025_QPV_2024/data_RPLS2025_QP24.csv','CodGeo')
RPE=rd('RPLS_01-01-2025_QPV_2024/data_RPLS2025_ZONAGESQP24_QPV.csv','CodGeo')
POP={r['codeQPV']:r for r in csv.DictReader(open(CFG['pop_qpv'],encoding='utf-8-sig'))}
def ratio(a,b):
    a,b=num(a),num(b)
    return round(100*a/b,1) if a is not None and b else None
def ind(code,e,rv,df,cf,ed,dn,sd,rp,pop):
    g=lambda d,k:num(d.get(k)) if d else None
    popv=num(pop.get('popMuniQPV')) if pop else None
    I={}
    for k in ['partPop0_14','partPop15_24','partPop25_59','partPop60_74','partPop75p','indiceJeunesse','partPopEt','partPopImmi','partFamMono','partMen1p','partMen6pp',
              'txEmp','txEmpF','txChom','partEmpDurLim','part16_25nonScolNonEmp','partTpsPart','partOuvr','partEmpl',
              'partPopSansDip','partPopBepCap','partPopBacSup','txScol15_24',
              'partMenLoc','partMenProp','partResPrincSurocc','partResPrincEmm2','nbPersResPrinc','partResPrincAch46_70',
              'partTEC','partVoit','partMenVoit']:
        I[k]=g(e,k)
    I['revMed']=g(rv,'DISP_MED_A21');I['tp60']=g(rv,'DISP_TP60_A21');I['ppsoc']=g(rv,'DISP_PPSOC_A21');I['ppmini']=g(rv,'DISP_PPMINI_A21')
    if df:
        I['defm']=g(df,'ABC');I['defm25']=ratio(df.get('ABC_25'),df.get('ABC'));I['defmLD']=ratio(df.get('ABC_Dur4'),df.get('ABC'));I['defmF']=ratio(df.get('ABC_F'),df.get('ABC'));I['defmInf']=ratio(df.get('ABC_INFCAPBEP'),df.get('ABC'))
    if cf:
        I['caf']=g(cf,'A');I['cafMono']=ratio(cf.get('AM'),cf.get('A'));I['cafRSA']=ratio(cf.get('ARSAS'),cf.get('A'));I['cafAAH']=ratio(cf.get('AAAH'),cf.get('A'));I['cafLog']=ratio(cf.get('AAL'),cf.get('A'))
        if popv: I['cafCouv']=round(100*num(cf['PERCOU'])/popv,1) if num(cf.get('PERCOU')) else None
    if ed:
        for k in ['EC_MAT','EC_ELEM','EC_PRI','COLL','COLL_REP','COLL_REP_P','EFF_ECO','EFF_COLL','LYC']:
            I[k]=g(ed,k)
        I['ecoles']=sum(g(ed,k) or 0 for k in ['EC_MAT','EC_ELEM','EC_PRI']);I['ecolesREP']=sum(g(ed,k) or 0 for k in ['EC_MAT_REP','EC_ELEM_REP','EC_PRI_REP','EC_MAT_REP_P','EC_ELEM_REP_P','EC_PRI_REP_P'])
        I['ret6']=ratio(ed.get('RET_E6'),ed.get('EFF_E6'));I['ret3']=ratio(ed.get('RET_E3'),ed.get('EFF_E3'));I['defaColl']=ratio(ed.get('DEFA_COLL'),ed.get('EFF_COLL'));I['boursColl']=ratio(ed.get('COLL_BOURSIER'),ed.get('EFF_COLL'))
        I['collREP']=ratio(str((num(ed.get('EFF_COLSEG_REP')) or 0)+(num(ed.get('EFF_COLSEG_REP_P')) or 0)),ed.get('EFF_COLSEG'));I['lycPro']=ratio(ed.get('EFF_LYC_PRO'),str((num(ed.get('EFF_LYC_PRO')) or 0)+(num(ed.get('EFF_LYC_GT')) or 0)))
    if dn:
        a=(num(dn.get('EFF_REU_PUB')) or 0)+(num(dn.get('EFF_REU_PRI')) or 0);b=(num(dn.get('EFF_DNB_PUB')) or 0)+(num(dn.get('EFF_DNB_PRI')) or 0)
        I['dnb']=round(100*a/b,1) if b>=10 else None
    if sd:
        I['etab']=g(sd,'NBETAB')
        if popv and I['etab'] is not None: I['etab1000']=round(1000*I['etab']/popv,1)
    if rp:
        I['ls']=g(rp,'nbLsPls');I['lsVac']=g(rp,'txVac');I['lsRot']=g(rp,'txRot');I['lsLoy']=g(rp,'medLoy');I['lsPlai']=g(rp,'txLsPlai');I['lsAv75']=None
        a=sum(num(rp.get(k)) or 0 for k in ['txLsAv49','txLs49a75']);I['lsAv75']=round(a,1)
    return {k:v for k,v in I.items() if v is not None}
out={}
for code,pop in POP.items():
    out[code]={'n':pop['libQPV'],'com':pop['ListeLibDepcom'],'cc':pop['listeDepcom'],'dep':pop['listeDep'],'pop':int(pop['popMuniQPV']) if pop['popMuniQPV'].isdigit() else None,
      'i':ind(code,EST.get(code),REV.get(code),DEF.get(code),CAF.get(code),EDU.get(code),DNB.get(code),SID.get(code),RP.get(code),pop)}
REF=ind('00',ESTR.get('00_QPV24'),REVE.get('00'),DEFE.get('France hors Mayotte'),CAFE.get('France hors Mayotte'),EDUE.get('France hors Mayotte'),DNBE.get('France hors Mayotte'),None,RPE.get('00'),None)
print(len(out),len(REF),sorted(REF.items())[:60])
json.dump({'Q':out,'REF':REF},open(CFG['portrait'],'w'),ensure_ascii=False,separators=(',',':'))
