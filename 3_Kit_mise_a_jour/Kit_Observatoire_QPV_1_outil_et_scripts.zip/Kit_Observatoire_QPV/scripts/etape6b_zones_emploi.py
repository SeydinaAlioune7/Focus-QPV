# Étape 6b : zones d'emploi 2020 (Insee) : contours par regroupement des communes + indicateurs -> intermediaire/ze_geo.json
# Entrées : sources/zones_emploi/ze2020.json (table communes -> zone, insee.fr/fr/information/4652957, compactée),
#           sources/zones_emploi/chomage_ze.json ([code, taux dernier trimestre, taux un an avant], insee.fr/fr/statistiques/1893230)
# Pour mettre à jour le chômage : recopier les deux colonnes du fichier Insee dans chomage_ze.json et changer PERIODE.
import json,collections
from config import P
PERIODE='2e trimestre 2026'
from shapely.geometry import shape,mapping
from shapely.ops import unary_union
Z=json.load(open(P['ze_dir']+'ze2020.json'));zc=[z[0] for z in Z['Z']]
C={};s=Z['C']
for i in range(0,len(s),7):C[s[i:i+5]]=int(s[i+5:i+7],36)
F=json.load(open(P['communes_geo']))['features']
G=collections.defaultdict(list);miss=0
for f in F:
    k=C.get(f['properties']['code'])
    if k is None:miss+=1;continue
    G[k].append(shape(f['geometry']).buffer(0))
print('communes sans ZE',miss)
d=json.load(open(P['data_c']));U=d['U'];S=d['S']
O=json.load(open(P['obs']));ent={c[0]:c[4] for c in O['COMMUNES']}
st=collections.defaultdict(lambda:[0,0,0,0,0,0,0])
for i,c in enumerate(U['c']):
    cc=U['pa'].get(c,c) if c not in C else c
    k=C.get(c,C.get(cc))
    if k is None:continue
    a=st[k];a[0]+=max(U['p'][i],0);a[1]+=U['q'][i];a[2]+=S['tot'][i];a[3]+=S['qpv'][i];a[4]+=S['att'][i]
for c,e in ent.items():
    k=C.get(c)
    if k is not None:st[k][5]+=e
nq=collections.Counter()
for k in range(len(d['Q']['q'])):
    z=C.get(d['Q']['c'][k])
    if z is not None:nq[z]+=1
CH={c:(a,b) for c,a,b in json.load(open(P['ze_dir']+'chomage_ze.json'))}
feats=[]
def rnd(o):
    return [rnd(x) for x in o] if o and isinstance(o[0],(list,tuple)) else [round(o[0],3),round(o[1],3)]
for k,gs in G.items():
    g=unary_union([x.buffer(0.002) for x in gs]).buffer(-0.002).simplify(0.009,preserve_topology=True)
    if g.geom_type=='MultiPolygon':
        from shapely.geometry import MultiPolygon
        g=MultiPolygon([p for p in g.geoms if p.area>2e-5]) if any(p.area>2e-5 for p in g.geoms) else g
    a=st[k];feats.append({'type':'Feature','properties':{'c':zc[k],'n':Z['Z'][k][1],'pop':a[0],'pq':a[1],'ls':a[2],'lq':a[3],'att':a[4],'ent':a[5],'nq':nq[k],'tc':CH.get(zc[k],(None,None))[0],'tc1':CH.get(zc[k],(None,None))[1]},'geometry':{'type':g.geom_type,'coordinates':rnd(mapping(g)['coordinates'])}})
json.dump({'type':'FeatureCollection','periode':PERIODE,'features':feats},open(P['ze'],'w'),ensure_ascii=False,separators=(',',':'))
import os;print(len(feats),os.path.getsize(P['ze']))
print([f['properties'] for f in feats if 'Lyon' in f['properties']['n']])
