# Étape 7a : assemble l'outil complet (un seul fichier HTML) à partir de front/ et intermediaire/.
# Usage : python etape7a_assembler.py   -> sortie/Observatoire_QPV_Action_Logement.html
import builtins,os,sys,json
from config import P
_open=builtins.open
def build(out_name,override=None,badge=None):
    def op(f,mode='r',*a,**k):
        if isinstance(f,str) and not os.path.isabs(f):
            if 'w' in mode:
                if f=='observatoire_qpv_entreprise.html':f=P['out']+out_name
                else:f=P['mid']+f
            else:
                for d in [override,P['mid'],P['front']]:
                    if d and os.path.exists(os.path.join(d,f)):f=os.path.join(d,f);break
        return _open(f,mode,*a,**k)
    src=_open(P['front']+'_assemble_core.py',encoding='utf-8').read()
    if badge:
        src=src.replace("out=sh.replace(","sh=sh.replace('<b>Observatoire des quartiers prioritaires</b>','<b>Observatoire des quartiers prioritaires <span style=\"background:#E2004B;color:#fff;border-radius:4px;padding:1px 7px;font-size:11px;vertical-align:2px;margin-left:6px\">"+badge+"</span></b>',1)\nout=sh.replace(",1)
    builtins.open=op
    try:exec(compile(src,'_assemble_core.py','exec'),{'__name__':'__main__'})
    finally:builtins.open=_open
    print('->',P['out']+out_name,round(os.path.getsize(P['out']+out_name)/1e6,1),'Mo')
def atlas_page(data_path,out_path):
    d=_open(data_path,encoding='utf-8').read().replace('</','<\\/')
    h=_open(P['front']+'page_head.html',encoding='utf-8').read();b=_open(P['front']+'page_body.html',encoding='utf-8').read()
    _open(out_path,'w',encoding='utf-8').write(h+b.replace('__DATA__',d))
if __name__=='__main__':
    os.makedirs(P['out'],exist_ok=True)
    atlas_page(P['data_c'],P['atlas_html'])
    build('Observatoire_QPV_Action_Logement.html')
