# Étape 1b : data.json -> data_c.json (format colonnes lu par la page)
# Transforme data.json (sortie de build_data.py) en data_c.json (format colonnes, utilisé par la page)
import json
from config import P
d=json.load(open(P['data_json'],encoding='utf-8'));U=d['units'];el=sorted(d['epci']);ei={e:i for i,e in enumerate(el)}
j=lambda g:'|'.join(','.join(r) for r in g)
col={'c':[u['c'] for u in U],'n':[u['n'] for u in U],'d':[u['d'] for u in U],'e':[ei.get(u['e'],-1) for u in U],
 'p':[u['p'] if u['p'] is not None else -1 for u in U],'q':[u['q'] for u in U],'l':[v for u in U for v in u['l']],
 'g':[j(u['g']) for u in U],'pa':{u['c']:u['pa'] for u in U if 'pa' in u}}
Q=d['qpv'];qc={k:[x[k] for x in Q] for k in ['q','n','c','lc','d']};qc['g']=[j(x['g']) for x in Q]
out={'cu':d['cu'],'qu':d['qu'],'unit':d['unit'],'U':col,'Q':qc,'O':[{'c':o['c'],'n':o['n'],'g':j(o['g'])} for o in d['outlines']],
 'epci':[[e,d['epci'][e]] for e in el],'dep':d['dep'],'ref':d['ref']}
open(P['data_c'],'w',encoding='utf-8').write(json.dumps(out,ensure_ascii=False,separators=(',',':')))
