# Étape 5c : évolutions par commune (passoires RPLS N-1 et N, familles logées par année, logements réservés par année) -> intermediaire/evol.json
# Entrées : rpls2023_commune.csv, rpls2024_commune.csv (requêtes 9 et 10), attributions_commune_annee.csv (11), polaris_operations.csv (8)
# Pour changer de millésimes : modifier ANNEES_ATTRIB et PERIODE_RESA ci-dessous, et le texte de atlas_evol.js.
import json,collections
from config import P,lire_pbi,num
ANNEES_ATTRIB={'2022':6,'2024':7,'2025':8}     # position dans le tableau (ne pas changer les positions 6,7,8)
PERIODE_RESA=(2018,2025)                         # 8 années d'engagement
E=collections.defaultdict(lambda:[0]*9+[[0]*8])
for i,f in enumerate(['rpls2023_commune.csv','rpls2024_commune.csv']):
    for r in lire_pbi(f):
        if not r[0]:continue
        e=E[r[0].split('.')[0].zfill(5)];e[3*i]+=int(num(r[1]) or 0);e[3*i+1]+=int(num(r[2]) or 0);e[3*i+2]+=int(num(r[3]) or 0)
for r in lire_pbi('attributions_commune_annee.csv'):
    k=ANNEES_ATTRIB.get(r[1].split('.')[0])
    if r[0] and k:E[r[0].split('.')[0].zfill(5)][k]+=int(num(r[2]) or 0)
for r in lire_pbi('polaris_operations.csv'):
    y=int(num(r[5]) or 0)
    if PERIODE_RESA[0]<=y<=PERIODE_RESA[1]:E[r[3].split('.')[0].zfill(5)][9][y-PERIODE_RESA[0]]+=int(num(r[6]) or 0)
out={c:e for c,e in E.items() if any(e[:9]) or any(e[9])}
json.dump(out,open(P['evol'],'w'),separators=(',',':'))
print('communes',len(out),'· familles logées',[sum(e[k] for e in out.values()) for k in (6,7,8)])
