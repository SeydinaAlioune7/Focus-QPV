# Étape 3 : adresses géolocalisées du parc social -> intermediaire/rpls_pts.json (lu par l'onglet Adresse)
# Entrée : intermediaire/rpls_fr_geo.json (étape 2). Une ligne par adresse : coordonnées WGS84, logements, F/G, E, étiquetés, vacants, bailleur, QPV.
import json,collections
from config import P
AL='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_';AI={c:i for i,c in enumerate(AL)}
COLS=['lat','lon','tot','fg','e','et','vac','b','q']
def enc(vals,cum):
    o=[];prev=0
    for x in vals:
        d=x-prev if cum else x;prev=x;z=2*d if d>=0 else -2*d-1
        while True:
            c=z&31;z>>=5
            if z:o.append(AL[c|32])
            else:o.append(AL[c]);break
    return ''.join(o)
def dec(s,cum):
    out=[];v=0;m=1;acc=0
    for ch in s:
        b=AI[ch];v+=(b&31)*m
        if b&32:m*=32
        else:
            x=-(v+1)//2 if v%2 else v//2
            if cum:acc+=x;out.append(acc)
            else:out.append(x)
            v=0;m=1
    return out
def load_points():
    PT=json.load(open(P['points']));return PT,{k:dec(PT['c'][j],j<2) for j,k in enumerate(COLS)}
if __name__=='__main__':
    from pyproj import Transformer
    TR={'M':Transformer.from_crs(2154,4326,always_xy=True),'971':Transformer.from_crs(5490,4326,always_xy=True),'972':Transformer.from_crs(5490,4326,always_xy=True),
        '973':Transformer.from_crs(2972,4326,always_xy=True),'974':Transformer.from_crs(2975,4326,always_xy=True),'976':Transformer.from_crs(4471,4326,always_xy=True)}
    G=json.load(open(P['rpls_geo']));A=collections.OrderedDict()
    for r in G:
        if r[13]=='' or r[13] is None:continue
        dep=r[0][:3] if r[0].startswith('97') else 'M'
        lon,lat=TR.get(dep,TR['M']).transform(r[13],r[14]);key=(round(lat,5),round(lon,5),r[6],r[15])
        a=A.setdefault(key,[0,0,0,0,0]);e=r[17] if len(r)>17 else 0
        a[0]+=r[7];a[1]+=r[9];a[2]+=e;a[3]+=r[10];a[4]+=r[11]
    bn=sorted({k[2] for k in A});bi={n:i for i,n in enumerate(bn)};qn=sorted({k[3] for k in A if k[3]});qi={c:i+1 for i,c in enumerate(qn)}
    K=sorted(A,key=lambda k:(k[0],k[1]))
    cols=[[round(k[0]*1e5) for k in K],[round(k[1]*1e5) for k in K]]+[[A[k][j] for k in K] for j in range(5)]+[[bi[k[2]] for k in K],[qi.get(k[3],0) for k in K]]
    out={'n':len(K),'c':[enc(c,j<2) for j,c in enumerate(cols)],'b':bn,'q':qn}
    json.dump(out,open(P['points'],'w'),ensure_ascii=False,separators=(',',':'))
    print('adresses',len(K),'logements',sum(cols[2]),'bailleurs',len(bn),'QPV',len(qn))
