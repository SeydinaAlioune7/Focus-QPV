# Étape 1c : ajoute à data_c.json le parc social (RPLS), les attributions Action Logement, la population et les bailleurs par QPV.
# Entrées : sources/action_logement/rpls_par_commune.csv (requête 1), attributions_commune.csv (requête 2),
#           sources/insee/pop_QPV24.csv, intermediaire/rpls_pts.json (étape 3, pour les bailleurs par QPV).
import json,csv,collections,os
from config import P
d=json.load(open(P['data_c'],encoding='utf-8'));U=d['U'];N=len(U['c']);iu={c:i for i,c in enumerate(U['c'])}
c26=json.load(open(P['cog2026']))
act={x['code'] for x in c26 if x['type'] in('commune-actuelle','arrondissement-municipal')}
chef={x['code']:x['chefLieu'] for x in c26 if x['type'] in('commune-deleguee','commune-associee') and x.get('chefLieu')}
def to26(c):
    c=(c or '').strip().zfill(5)
    if c in act:return c
    return chef.get(c)
def num(x):
    try:return float(str(x).replace(',','.'))
    except:return 0
def rows(name):
    p=P['pbi']+name
    f=open(p,encoding='utf-8-sig');first=f.readline();f.seek(0)
    return list(csv.DictReader(f,delimiter=';' if first.count(';')>first.count(',') else ','))
S={k:[0]*N for k in['tot','qpv','fg','et','vac','att']};lost=collections.Counter()
for r in rows('rpls_par_commune.csv'):
    t=to26(r['depcom'])
    if t not in iu:lost['rpls']+=num(r['tot']);continue
    i=iu[t]
    for k in['tot','qpv','fg','et','vac']:S[k][i]+=int(num(r[k]))
for r in rows('attributions_commune.csv'):
    t=to26(r['code'])
    if t not in iu:lost['att']+=num(r['familles']);continue
    S['att'][iu[t]]+=int(num(r['familles']))
d['S']=S
Q=d['Q'];pq={r['codeQPV']:int(r['popMuniQPV']) for r in csv.DictReader(open(P['pop_qpv'],encoding='utf-8-sig')) if r['popMuniQPV'].isdigit()}
Q['p']=[pq.get(c,-1) for c in Q['q']]  # -1 = population non publiée (Mayotte)
# bailleurs par QPV (à partir des points géolocalisés)
if os.path.exists(P['points']):
    from build_points import load_points
    PT,cols=load_points();tot,b,q=cols['tot'],cols['b'],cols['q'];agg=collections.defaultdict(collections.Counter)
    for i in range(PT['n']):
        if q[i]:agg[PT['q'][q[i]-1]][PT['b'][b[i]]]+=tot[i]
    Q['b']=[[sum(agg[c].values())]+[[n,v] for n,v in agg[c].most_common(6)] for c in Q['q']]
json.dump(d,open(P['data_c'],'w',encoding='utf-8'),ensure_ascii=False,separators=(',',':'))
print('parc social',sum(S['tot']),'dont QPV',sum(S['qpv']),'· familles logées',sum(S['att']),'· non rattachés',dict(lost))
print('QPV avec population',sum(1 for v in Q['p'] if v),'/',len(Q['p']))
