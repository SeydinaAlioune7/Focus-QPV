# Étape 4c : complète qpv_portrait.json : surface, écoles (dans le QPV et à moins de 300 m), bailleurs du QPV, poids dans les communes.
# Entrées : qpv_portrait.json (build_qpv.py + build_com.py), contours QPV (Lambert/UTM), annuaire de l'Éducation nationale,
#           rpls_pts.json (build_points.py), data_c.json (Atlas), contours des communes.
import json,csv,collections
from shapely.geometry import shape,Point
from shapely.strtree import STRtree
from shapely.ops import unary_union,transform
from pyproj import Transformer
from config import P
d=json.load(open(P['portrait']))
# --- contours QPV en mètres (projections officielles)
QF={'QP2024_France_hexagonale_LB93.geojson':2154,'QP2024_Guadeloupe_RGAF09_UTM20N.geojson':5490,'QP2024_Martinique_RGAF09_UTM20N.geojson':5490,
    'QP2024_Guyane_RGF95_UTM22N.geojson':2972,'QP2024_LaReunion_RGR92_UTM40S.geojson':2975,'QP2024_Mayotte_RGM04_UTM38S.geojson':4471}
QG={};QE={}
for f,epsg in QF.items():
    tr=Transformer.from_crs(4326,epsg,always_xy=True)
    for x in json.load(open(P['qpv_dir']+f))['features']:
        c=x['properties']['code_qp'];QG[c]=shape(x['geometry']);QE[c]=tr
# --- écoles
S=[];SP=[]
for r in csv.DictReader(open(P['annuaire'],encoding='utf-8-sig'),delimiter=';'):
    if r.get('etat','OUVERT')!='OUVERT' or not r['latitude']:continue
    t={'Ecole':'E','Collège':'C','Lycée':'L'}.get(r['type_etablissement'])
    if not t:continue
    S.append([round(float(r['latitude']),5),round(float(r['longitude']),5),t,r['appartenance_education_prioritaire'],'Pu' if r['statut_public_prive']=='Public' else 'Pr',r['nom_etablissement']])
print('écoles',len(S))
# --- points RPLS par QPV
import base64
AL='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_';AI={c:i for i,c in enumerate(AL)}
def dec(s,cum):
    out=[];v=0;m=1;acc=0
    for ch in s:
        b=AI[ch];v+=(b&31)*m
        if b&32:m*=32
        else:
            x=-(v+1)//2 if v%2 else v//2
            if cum:acc+=x;out.append(acc)
            else:out.append(x)
            v=0;m=1
    return out
PT=json.load(open(P['points']));cols=[dec(PT['c'][i],i<2) for i in range(len(PT['c']))]
tot,fg,e,et,vac,b,q=cols[2:9]
BL=collections.defaultdict(lambda:collections.defaultdict(lambda:[0,0,0,0]))
for i in range(PT['n']):
    if q[i]:
        a=BL[PT['q'][q[i]-1]][PT['b'][b[i]]];a[0]+=tot[i];a[1]+=fg[i];a[2]+=et[i];a[3]+=e[i]
# --- communes (Atlas) pour les parts communales
A=json.load(open(P['data_c']));U=A['U'];iu={c:i for i,c in enumerate(U['c'])};SS=A['S']
CG={}
for gf in (P['communes_geo'],P['arr_geo']):
    for f in json.load(open(gf))['features']:CG[f['properties']['code']]=shape(f['geometry'])
tr=Transformer.from_crs(4326,2154,always_xy=True)
byCom=collections.defaultdict(list)
for code,x in d['Q'].items():
    for c in str(x.get('cc','')).replace(';',',').split(','):
        if c.strip():byCom[c.strip()].append(code)
for code,x in d['Q'].items():
    g=QG.get(code)
    if g is None:continue
    x['area']=round(g.area/1e4,1)
    # écoles : dans le QPV, puis à moins de 300 m
    wgs=Transformer.from_crs(QE[code].target_crs,4326,always_xy=True)
    sch=[];schN=[]
    bb=transform(wgs.transform,g.buffer(300)).bounds
    for k,s in enumerate(S):
        if not(bb[1]<=s[0]<=bb[3] and bb[0]<=s[1]<=bb[2]):continue
        p=Point(QE[code].transform(s[1],s[0]))
        if g.contains(p):sch.append(k)
        elif g.distance(p)<=300:schN.append(k)
    x['sch']=sch;x['schN']=schN
    x['bl']=sorted([[n]+v for n,v in BL.get(code,{}).items()],key=lambda r:-r[1])
    cs=[]
    for c in str(x.get('cc','')).replace(';',',').split(','):
        c=c.strip();i=iu.get(c)
        if i is None:continue
        pop=round(100*U['q'][i]/U['p'][i],1) if U['p'][i]>0 else None
        parc=round(100*SS['qpv'][i]/SS['tot'][i],1) if SS['tot'][i] else None
        ar=None
        if c in CG and not c.startswith('97'):
            cg=transform(tr.transform,CG[c]);qu=unary_union([QG[k] for k in byCom[c] if k in QG and QE[k].target_crs.to_epsg()==2154])
            if cg.area:ar=round(100*qu.intersection(cg).area/cg.area,1)
        cs.append({'c':c,'n':U['n'][i],'pop':pop,'parc':parc,'area':ar})
    x['csh']=cs
# on ne garde que les établissements à moins de 1 km d'un QPV (fichier plus léger), avec renumérotation
keep=set()
for code,x in d['Q'].items():keep.update(x.get('sch',[]));keep.update(x.get('schN',[]))
near=[]
for code,g in QG.items():
    wgs=Transformer.from_crs(QE[code].target_crs,4326,always_xy=True);near.append(transform(wgs.transform,g.buffer(1000)).bounds)
from shapely.geometry import box
tree=STRtree([box(*b) for b in near])
for k,s_ in enumerate(S):
    if k in keep:continue
    if len(tree.query(Point(s_[1],s_[0]))):keep.add(k)
idx=sorted(keep);ren={k:i for i,k in enumerate(idx)}
for x in d['Q'].values():
    x['sch']=[ren[k] for k in x.get('sch',[])];x['schN']=[ren[k] for k in x.get('schN',[])]
d['S']=[S[k] for k in idx]
json.dump(d,open(P['portrait'],'w'),ensure_ascii=False,separators=(',',':'))
print('portrait complété',len(d['Q']))
