# Étape 7b : version de démonstration limitée à une DR (données filtrées, repères France conservés)
# Usage : python etape7b_version_dr.py "DR IDF"  -> sortie/Observatoire_QPV_v0_<DR>.html
import json,re,sys,os
from config import P
DRN=sys.argv[1] if len(sys.argv)>1 else 'DR IDF'          # ex. : python etape7b_version_dr.py "DR AURA"
DD=json.load(open(P['dep_dr']));DEPS={d for d,v in DD.items() if v[1]==DRN}
if not DEPS:sys.exit('DR inconnue : '+DRN+' · choix : '+', '.join(sorted({v[1] for v in DD.values()})))
O=P['mid']+'v0'+os.sep;os.makedirs(O,exist_ok=True)
_obs=json.load(open(P['obs']));_pts=[(c[1],c[2]) for c in _obs['COMMUNES'] if (c[0][:3] if c[0].startswith('97') else c[0][:2]) in DEPS]
LA0=min(p[0] for p in _pts)-.08;LA1=max(p[0] for p in _pts)+.08;LO0=min(p[1] for p in _pts)-.1;LO1=max(p[1] for p in _pts)+.1
AL='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_';AI={c:i for i,c in enumerate(AL)}
def dec(s,cum):
    out=[];v=0;m=1;acc=0
    for ch in s:
        b=AI[ch];v+=(b&31)*m
        if b&32:m*=32
        else:
            x=-(v+1)//2 if v%2 else v//2
            if cum:acc+=x;out.append(acc)
            else:out.append(x)
            v=0;m=1
    return out
def enc(vals,cum):
    o=[];prev=0
    for x in vals:
        d=x-prev if cum else x;prev=x
        z=2*d if d>=0 else -2*d-1
        while True:
            c=z&31;z>>=5
            if z:o.append(AL[c|32])
            else:o.append(AL[c]);break
    return ''.join(o)
# --- atlas
s=open(P['mid']+'atlas_qpv.html').read()
m=re.search(r'(<script id="data" type="application/json">)(.*?)(</script>)',s,re.S);D=json.loads(m.group(2))
U=D['U'];N=len(U['c']);keep=[i for i in range(N) if U['d'][i] in DEPS]
# national refs (same formulas as the page)
S=D['S']
def ind(num,den):return 100*sum(num)/sum(den)
qn=sum(U['q']);pn=sum(U['p'])
nat={'p':pn,'q':qn,'R':{'parc':ind(S['qpv'],S['tot']),'fg':ind(S['fg'],S['et']),'att':ind(S['att'],S['tot']),'vac':ind(S['vac'],S['tot'])}}
for k in list(U):
    if k=='pa':continue
    if k=='l':U[k]=[v for i in keep for v in (U['l'][2*i],U['l'][2*i+1])]
    else:U[k]=[U[k][i] for i in keep]
for k in S:S[k]=[S[k][i] for i in keep]
Q=D['Q'];qk=[k for k in range(len(Q['q'])) if Q['d'][k] in DEPS]
for k in Q:Q[k]=[Q[k][j] for j in qk]
D['nat']=nat
s=s[:m.start(2)]+json.dumps(D,separators=(',',':'),ensure_ascii=False)+s[m.end(2):]
s=s.replace("REFS.pop=100*D.ref.q/D.ref.pop;","REFS.pop=100*D.ref.q/D.ref.pop;if(D.nat){for(const k in D.nat.R){REFS[k]=D.nat.R[k];HEXS[k]=D.nat.R[k]}}",1)
import collections
_ep=collections.Counter();_dp=collections.Counter()
for i in range(len(U['c'])):_ep[U['e'][i]]+=U['q'][i];_dp[U['d'][i]]+=U['q'][i]
_e=D['epci'][_ep.most_common(1)[0][0]][1];_d=_dp.most_common(1)[0][0];_dl=D['dep'][_d][0]+' ('+_d+')'
s=s.replace("'Métropole de Lyon'",json.dumps(_e,ensure_ascii=False).replace('"',"'")).replace("'Rhône (69)'",json.dumps(_dl,ensure_ascii=False).replace('"',"'")).replace("'DR AURA'","'"+DRN+"'")
open(O+'atlas_qpv.html','w').write(s);print('atlas',len(keep),len(qk))
# --- rpls points
PTS=json.load(open(P['mid']+'rpls_pts.json'));c=PTS['c'];n=PTS['n']
la=dec(c[0],True);lo=dec(c[1],True);cols=[dec(x,False) for x in c[2:]]
idx=[i for i in range(n) if LA0<=la[i]/1e5<=LA1 and LO0<=lo[i]/1e5<=LO1]
P2={'n':len(idx),'c':[enc([la[i] for i in idx],True),enc([lo[i] for i in idx],True)]+[enc([col[i] for i in idx],False) for col in cols],'b':PTS['b'],'q':PTS['q']}
json.dump(P2,open(O+'rpls_pts.json','w'),separators=(',',':'),ensure_ascii=False);print('rpls',len(idx))
# --- QPV geo, portrait, obs, ops, evol
G=json.load(open(P['qpv_simpl']));qset=set(Q['q'])
G['features']=[f for f in G['features'] if f['properties']['code_qp'] in qset];json.dump(G,open(O+'qpv_wgs_simpl.json','w'),separators=(',',':'),ensure_ascii=False)
PQ=json.load(open(P['mid']+'qpv_portrait.json'));PQ['Q']={k:v for k,v in PQ['Q'].items() if k in qset}
used=set();[used.update(v.get('sch',[])+v.get('schN',[])) for v in PQ['Q'].values()]
inb=lambda a,b:LA0<=a<=LA1 and LO0<=b<=LO1
# school indices: keep list intact but blank out-of-area entries to preserve indices
PQ['S']=[s_ if (i in used or inb(s_[0],s_[1])) else [0,0,'E','','',''] for i,s_ in enumerate(PQ['S'])]
PQ['C']={k:v for k,v in PQ['C'].items() if (k[:3] if k.startswith('97') else k[:2]) in DEPS};json.dump(PQ,open(O+'qpv_portrait.json','w'),separators=(',',':'),ensure_ascii=False)
OB=json.load(open(P['mid']+'obs_small.json'));OB['GARES']=[g for g in OB['GARES'] if inb(g[1],g[2])];OB['COMMUNES']=[x for x in OB['COMMUNES'] if inb(x[1],x[2])]
json.dump(OB,open(O+'obs_small.json','w'),separators=(',',':'),ensure_ascii=False)
OP=json.load(open(P['mid']+'ops.json'));OP['r']=[r for r in OP['r'] if inb(r[0],r[1])];json.dump(OP,open(O+'ops.json','w'),separators=(',',':'),ensure_ascii=False)
E=json.load(open(P['mid']+'evol.json'));json.dump({k:v for k,v in E.items() if (k[:3] if k.startswith('97') else k[:2]) in DEPS},open(O+'evol.json','w'),separators=(',',':'))
print('done')
# assemblage de la version DR
from etape7a_assembler import build
nom=DRN.replace('DR ','').replace(' ','_')
build('Observatoire_QPV_v0_'+nom+'.html',override=O,badge='v0 · '+DRN)
