# Étape 5b : localisation des opérations POLARIS avec logements réservés (BAN) -> intermediaire/ops_geo.json et ops.json
# Entrée : sources/action_logement/polaris_operations.csv (requête n°8), fichiers BAN dans sources/ban/. Durée : 10 à 20 minutes.
import json,gzip,csv,re,collections,os
import os
src=open(os.path.join(os.path.dirname(os.path.abspath(__file__)),'etape2_geocodage_rpls.py')).read();exec(src[:src.find('import sys,os,glob')])
from config import P as CFG,lire_pbi
UP=CFG['ban_dir']
rows=lire_pbi('polaris_operations.csv')
ops={}
for ref,nom,adr,com,siren,an,r,m in rows:
    com=com.zfill(5);o=ops.setdefault(ref,{'ref':ref,'nom':nom,'adr':adr,'com':com,'s':siren.zfill(9),'res':0,'mt':0,'an':set()})
    o['res']+=int(float(r.replace(',','.') or 0));o['mt']+=float(m.replace(',','.') or 0);o['an'].add(an)
bydep=collections.defaultdict(list)
for o in ops.values():
    c=o['com'];d=c[:3] if c.startswith('97') else c[:2];bydep[d].append(o)
COM={c[0]:(c[1],c[2]) for c in json.load(open(CFG['obs']))['COMMUNES']}
st=collections.Counter()
for dep,L in sorted(bydep.items()):
    p=UP+f'adresses-with-ids-{dep}.csv.gz';ban=collections.defaultdict(lambda: collections.defaultdict(list))
    if os.path.exists(p):
        for r in csv.DictReader(gzip.open(p,'rt',encoding='utf-8'),delimiter=';'):
            if not r['lon']:continue
            v=voie(norm(r['nom_voie']));t=(int(r['numero']) if r['numero'].isdigit() else 0,'',float(r['lat']),float(r['lon']))
            ban[r['code_insee']][v].append(t)
            if r['code_insee_ancienne_commune']:ban[r['code_insee_ancienne_commune']][v].append(t)
    for o in L:
        a=re.sub(r'\s+\d{5}\s+.*$','',o['adr'] or '').strip()
        n,rep,v=parse_rpls(a,'','');streets=ban.get(o['com'],{});cand=streets.get(v);q=None;pt=None
        if cand is None and streets and v:
            m=process.extractOne(v,list(streets.keys()),scorer=fuzz.token_sort_ratio)
            if m and m[1]>=85:cand=streets[m[0]];q='voie'
        if cand:
            ex=[c for c in cand if c[0]==n] if n else []
            if ex:pt=ex[0][2:];q=q or 'exacte'
            else:xs=[c[2] for c in cand];ys=[c[3] for c in cand];pt=(sum(xs)/len(xs),sum(ys)/len(ys));q='voie'
        pc=o['com'];pc='75056' if pc.startswith('751') else '69123' if pc.startswith('6938') else '13055' if pc.startswith('132') else pc
        if pt is None and pc in COM:pt=COM[pc];q='commune'
        o['pt']=pt;o['q']=q or 'non';st[o['q']]+=o['res']
    print(dep,len(L),flush=True)
print(st)
out=[[o['ref'],o['nom'],o['adr'],o['com'],o['s'],o['res'],round(o['mt']),min(o['an']),max(o['an']),round(o['pt'][0],5),round(o['pt'][1],5),o['q']] for o in ops.values() if o['pt']]
json.dump(out,open(CFG['ops_geo'],'w'),ensure_ascii=False)
# version compacte pour l'outil (opérations localisées à l'adresse ou à la voie)
RS=json.load(open(CFG['resa']));nm=lambda s:(RS['B'].get(s) or [None])[0] or RS['N'].get(s) or s
Sx=sorted({o[4] for o in out});ix={s:i for i,s in enumerate(Sx)};qq={'exacte':'e','voie':'v','commune':'c'}
rows2=[[round(o[9],4),round(o[10],4),o[5],ix[o[4]],o[1].strip()[:50],'',o[7],o[8],qq[o[11]]] for o in out if o[11]!='commune']
json.dump({'n':[nm(s) for s in Sx],'r':rows2},open(CFG['ops'],'w'),ensure_ascii=False,separators=(',',':'))
print(len(out),len(ops))
