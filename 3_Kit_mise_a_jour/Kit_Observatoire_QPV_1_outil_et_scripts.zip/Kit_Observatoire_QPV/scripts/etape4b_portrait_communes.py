# Étape 4b : valeurs des communes et poids du quartier dans sa commune (Insee DEFM, CAF, EDUC, DNB, RPLS communaux)
import json,csv
import os
src=open(os.path.join(os.path.dirname(__file__),'etape4a_portrait_insee.py')).read();exec(src[:src.find('\nout={}')])
DEFC=rd('DEFM2024_QP24_csv/data_DEFM2024_com.csv','CODGEO');CAFC=rd('beneficiaires_CAF_31-12-2024_QP24/data_CAF2024_COM.csv','CODGEO')
EDUC_=rd('EDUC_2024_2025_QP24/data_EDUC_2024_2025_com.csv','CODGEO');DNBC=rd('DNB_2025_QP24/data_DNB_2025_com.csv','CODGEO')
RPF=rd('RPLS_01-01-2025_QPV_2024/data_RPLS2025_ZONAGESQP24_FULL.csv','CodGeo')
POPC={c['code']:c.get('population') for c in json.load(open(CFG['cog2022']))}
PR={r['codeDepcom']:r for r in csv.DictReader(open(CFG['pop_ref'],encoding='utf-8-sig'))}
d=json.load(open(CFG['portrait']));C={}
for code,q in d['Q'].items():
  for c in str(q.get('cc','')).replace(';',',').split(','):
    c=c.strip()
    if not c or c in C:continue
    pc=POPC.get(c)
    pm={'popMuniQPV':str(pc)} if pc else None
    I=ind(c,None,None,DEFC.get(c),CAFC.get(c),EDUC_.get(c),DNBC.get(c),None,RPF.get(c),pm)
    I['_pop']=pc;I['_defm']=num(DEFC[c]['ABC']) if c in DEFC else None;I['_caf']=num(CAFC[c]['A']) if c in CAFC else None
    C[c]={k:v for k,v in I.items() if v is not None}
d['C']=C
# poids du quartier dans sa commune principale
for code,q in d['Q'].items():
  c=str(q.get('cc','')).replace(';',',').split(',')[0].strip();R=C.get(c,{});v=q['i'];w={}
  if R.get('_defm') and v.get('defm') is not None:w['defm']=round(100*v['defm']/R['_defm'],1)
  if R.get('_caf') and v.get('caf') is not None:w['caf']=round(100*v['caf']/R['_caf'],1)
  if R.get('ls') and v.get('ls') is not None:w['ls']=round(100*v['ls']/R['ls'],1)
  if R.get('_pop') and q.get('pop'):w['pop']=round(100*q['pop']/R['_pop'],1)
  q['w']=w;q['c0']=c
json.dump(d,open(CFG['portrait'],'w'),ensure_ascii=False,separators=(',',':'))
print(len(C));k='QN06901M' if 'QN06901M' in d['Q'] else list(d['Q'])[0];print(d['Q'][k]['n'],d['Q'][k]['w'],{x:C[d['Q'][k]['c0']].get(x) for x in ['defm25','cafRSA','dnb','lsVac','ret6','ls']},{x:d['Q'][k]['i'].get(x) for x in ['defm25','cafRSA','dnb','lsVac','ret6']})
