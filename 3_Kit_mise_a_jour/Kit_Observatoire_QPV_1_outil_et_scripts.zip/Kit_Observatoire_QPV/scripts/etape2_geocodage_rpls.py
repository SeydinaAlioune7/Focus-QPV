# Étape 2 : géolocalisation des adresses du parc social (RPLS) avec la Base Adresse Nationale, puis rattachement aux QPV.
# Entrée : sources/action_logement/rpls_adresses.csv (requête Power BI n°3), fichiers BAN adresses-with-ids-XX.csv.gz dans sources/ban/
#          (https://adresse.data.gouv.fr/data/ban/adresses/latest/csv-with-ids/), contours QPV dans sources/qpv/.
# Sortie : intermediaire/rpls_fr_geo.json. Durée : 30 à 60 minutes pour la France. Paquets : rapidfuzz, shapely.
import json,gzip,csv,re,unicodedata,collections
from rapidfuzz import process,fuzz
from shapely.geometry import shape,Point
from shapely.strtree import STRtree
TYP={'BOULEVARD':'BD','BD':'BD','BLD':'BD','BVD':'BD','AVENUE':'AV','AV':'AV','AVE':'AV','RUE':'R','R':'R','PLACE':'PL','PL':'PL','ALLEE':'ALL','ALLEES':'ALL','ALL':'ALL','IMPASSE':'IMP','IMP':'IMP','CHEMIN':'CHE','CHE':'CHE','CH':'CHE','ROUTE':'RTE','RTE':'RTE','QUAI':'QU','QU':'QU','COURS':'CRS','CRS':'CRS','SQUARE':'SQ','SQ':'SQ','RESIDENCE':'RES','RES':'RES','CITE':'CITE','PASSAGE':'PAS','PAS':'PAS','SENTIER':'SEN','SEN':'SEN','VOIE':'VOIE','VILLA':'VLA','VLA':'VLA','PROMENADE':'PROM','PROM':'PROM','RUELLE':'RLE','RLE':'RLE','ESPLANADE':'ESP','ESP':'ESP','PARVIS':'PRV','CARREFOUR':'CAR','ROND':'RPT','HAMEAU':'HAM','HAM':'HAM','SENTE':'SEN','MAIL':'MAIL','PARC':'PARC','DOMAINE':'DOM','DOM':'DOM','LOTISSEMENT':'LOT','LOT':'LOT','ZAC':'ZAC','GRANDE':'GDE','GDE':'GDE','GRAND':'GD','GD':'GD','SAINT':'ST','ST':'ST','SAINTE':'STE','STE':'STE','DOCTEUR':'DR','DR':'DR','GENERAL':'GAL','GAL':'GAL','GEN':'GAL','MARECHAL':'MAL','MAL':'MAL','PRESIDENT':'PDT','PDT':'PDT','PROFESSEUR':'PR','PROF':'PR','COMMANDANT':'CDT','CDT':'CDT','CAPITAINE':'CAP','LIEUTENANT':'LT','COLONEL':'COL','ADJUDANT':'ADJ','SERGENT':'SGT','MONSIEUR':'M','NOTRE':'N','DAME':'D'}
STOP={'DE','DU','DES','LA','LE','LES','L','D','A','AU','AUX','ET','EN'}
REPS={'BIS':'B','B':'B','TER':'T','T':'T','QUATER':'Q','Q':'Q','A':'A','C':'C','D':'D'}
def norm(s):
    s=(s or '').replace('\ufffd','E')
    s=unicodedata.normalize('NFKD',s).encode('ascii','ignore').decode().upper()
    s=re.sub(r'\b(BAT|BATIMENT|BT|ESC|ESCALIER|ENTREE|HALL|LOGT|APPT)\b.*$','',s)
    s=re.sub(r'(\d+)\s*-\s*\d+',r'\1',s)
    s=re.sub(r"[^A-Z0-9 ]",' ',s);return s.split()
def voie(tokens):
    o=[]
    for t in tokens:
        if t in STOP: continue
        t=TYP.get(t,t)
        if o and o[-1]==t: continue
        o.append(t)
    return ' '.join(o)
def parse_rpls(num,typ,nom):
    tok=norm(' '.join([num or '',typ or '',nom or '']))
    n=None;rep=''
    if tok and re.fullmatch(r'\d+(BIS|TER|QUATER|[A-Z])?',tok[0]):
        m=re.fullmatch(r'(\d+)([A-Z]*)',tok[0]);n=int(m.group(1));rep=m.group(2);tok=tok[1:]
        n=n or None
        while tok and re.fullmatch(r'\d+',tok[0]): tok=tok[1:]  # 12 14 rue
        if tok and tok[0] in ('BIS','TER','QUATER') : rep=REPS[tok[0]];tok=tok[1:]
        elif tok and len(tok[0])==1 and tok[0] in REPS and len(tok)>1 and tok[1] in TYP: rep=REPS[tok[0]];tok=tok[1:]
    return n,REPS.get(rep,rep),voie(tok)
import sys,os,glob
from shapely.geometry import shape,Point
from shapely.strtree import STRtree
from config import P as CFG
UP=CFG['ban_dir']
def _rows():
    f=open(CFG['pbi']+'rpls_adresses.csv',encoding='utf-8-sig');first=f.readline();f.seek(0);sep=';' if first.count(';')>first.count(',') else ','
    rd=csv.reader(f,delimiter=sep);next(rd)
    for r in rd:
        r=[x.strip() for x in r]
        if len(r)>=12 and r[0]:r[0]=r[0].zfill(5);r[5]=r[5].zfill(9);yield r
rows_all=list(_rows())
bydep=collections.defaultdict(list)
for r in rows_all:
    d=r[0][:3] if r[0].startswith('97') else r[0][:2]
    bydep[d].append(r)
QF={'M':'QP2024_France_hexagonale_LB93.geojson','971':'QP2024_Guadeloupe_RGAF09_UTM20N.geojson','972':'QP2024_Martinique_RGAF09_UTM20N.geojson','973':'QP2024_Guyane_RGF95_UTM22N.geojson','974':'QP2024_LaReunion_RGR92_UTM40S.geojson','976':'QP2024_Mayotte_RGM04_UTM38S.geojson'}
QPV={}
for z,f in QF.items():
    feats=json.load(open(CFG['qpv_dir']+f))['features'];g=[shape(x['geometry']).buffer(15) for x in feats]
    QPV[z]=(feats,g,STRtree(g))
out=[];stat=collections.Counter();missing=[]
for dep,rows in sorted(bydep.items()):
    p=UP+f'adresses-with-ids-{dep}.csv.gz'
    if not os.path.exists(p): missing.append(dep)
    ban=collections.defaultdict(lambda: collections.defaultdict(list))
    if os.path.exists(p):
        for r in csv.DictReader(gzip.open(p,'rt',encoding='utf-8'),delimiter=';'):
            if not r['x']: continue
            v=voie(norm(r['nom_voie']));rp=norm(r['rep']) if r['rep'] else []
            ban[r['code_insee']][v].append((int(r['numero']) if r['numero'].isdigit() else 0,REPS.get(rp[0],'') if rp else '',float(r['x']),float(r['y'])))
            if r['code_insee_ancienne_commune']: ban[r['code_insee_ancienne_commune']][v].append(ban[r['code_insee']][v][-1])
    fuzzcache={}
    feats,geoms,tree=QPV[dep if dep in QF else 'M']
    for r in rows:
        ins,num,typ,nom,cp,siren,rs=r[:7];tot,q,fg,et,vac=[int(float(x or 0)) for x in r[7:12]];e=int(float(r[12] or 0)) if len(r)>12 else 0
        n,rep,v=parse_rpls(num,typ,nom);streets=ban.get(ins,{})
        qual=None;pt=None;cand=streets.get(v)
        if cand is None and streets:
            k=v
            if k not in fuzzcache or True:
                key=(ins,v)
                if key not in fuzzcache:
                    m=process.extractOne(v,list(streets.keys()),scorer=fuzz.token_sort_ratio)
                    if not(m and m[1]>=85): m=process.extractOne(v,list(streets.keys()),scorer=fuzz.token_set_ratio);m=m if m and m[1]>=92 and len(v)>=6 else None
                    fuzzcache[key]=m[0] if m else None
                if fuzzcache[key]: cand=streets[fuzzcache[key]];qual='voie_approchee'
        if cand:
            ex=[c for c in cand if c[0]==n and c[1]==rep] or [c for c in cand if c[0]==n]
            if ex and n: pt=ex[0][2:];qual=qual or 'exacte'
            elif n:
                same=[c for c in cand if c[0] and c[0]%2==n%2] or [c for c in cand if c[0]]
                if same: c=min(same,key=lambda c:abs(c[0]-n));pt=c[2:];qual=(qual+'+' if qual else '')+'numero_voisin'
            if pt is None:
                xs=[c[2] for c in cand];ys=[c[3] for c in cand];pt=(sum(xs)/len(xs),sum(ys)/len(ys));qual=(qual+'+' if qual else '')+'centre_voie'
        code=lib=''
        if pt:
            P=Point(pt)
            for i in tree.query(P):
                if geoms[i].contains(P): code=feats[i]['properties']['code_qp'];lib=feats[i]['properties']['lib_qp'];break
        qk=(qual or 'non_trouve');qk='voie_approchee' if qk.startswith('voie_approchee') else qk.split('+')[0]
        stat[qk]+=tot
        out.append([ins,num,typ,nom,cp,siren,rs,tot,q,fg,et,vac,qual or 'non_trouve',round(pt[0],1) if pt else '',round(pt[1],1) if pt else '',code,lib,e])
    print(dep,len(rows),flush=True)
T=sum(stat.values());print({k:(v,round(100*v/T,1)) for k,v in stat.most_common()});print('BAN manquants',missing)
json.dump(out,open(CFG['rpls_geo'],'w'))
